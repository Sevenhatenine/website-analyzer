export type TwoFactorMethodType =
  | 'Both'
  | 'Phone Only'
  | 'Email Only'
  | 'App/Security Key'
  | 'None'
  | 'N/A';

export interface DomainRewardsInfo {
  hasRewardsOrPoints?: boolean;
  canEarn?: boolean;
  canWithdrawOrRedeem?: boolean;
  rewardsDetails?: string;
  hasGiftCards?: boolean;
  giftCardDetails?: string;
  isBankOrFinancial?: boolean;
  financialSubType?: string; // e.g., 'Retail Bank', 'Crypto Wallet / DeFi', 'Crypto Exchange', 'Investment & Brokerage', 'P2P Payment Wallet', 'Credit Card & Lending'
  financialDetails?: string; // Detailed explanation of financial features (crypto custody, ACH/wires, stock trading, P2P transfers, etc.)
  supportsPhone2FA?: string; // 'Yes', 'No', 'Optional', or 'N/A'
  supportsEmail2FA?: string; // 'Yes', 'No', 'Optional', or 'N/A'
  twoFactorType?: TwoFactorMethodType;
  twoFactorDetails?: string;
  loginVerificationGuide?: string; // Step-by-step instructions on how to log in using phone, email, or both
}

export interface DomainItem {
  domain: string;
  siteSubType?: string; // e.g., 'Retail Bank', 'Crypto Exchange & Wallet', 'Stock & Investment Brokerage', 'Online Marketplace', 'Airline & Frequent Flyer'
  description: string;
  tags?: string[];
  rewards?: DomainRewardsInfo;
  pastedCount?: number;
  pastedLabel?: string;
  rawOccurrences?: number;
}

export interface DomainCategory {
  id: string;
  name: string;
  description?: string;
  color?: string;
  icon?: string;
  items: DomainItem[];
}

export interface AnalysisStats {
  pastedLinesCount: number;
  totalDetectedItems: number;
  uniqueDomainsCount: number;
  duplicateMentionsCount: number;
  totalInstancesOrAccounts?: number;
}

export interface AnalysisResult {
  categories: DomainCategory[];
  markdown: string;
  totalDomains: number;
  modelUsed: string;
  timestamp: string;
  fallbackUsed?: boolean;
  note?: string;
  stats?: AnalysisStats;
}

export interface AnalysisRequest {
  domains: string[];
  domainMetadata?: Record<string, { count: number; label?: string; occurrences: number }>;
  provider?: 'gemini' | 'openai';
  model?: string;
  apiKey?: string;
  stats?: AnalysisStats;
}
