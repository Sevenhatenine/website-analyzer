import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DomainInput } from './components/DomainInput';
import { ResultsView } from './components/ResultsView';
import { ConfigDrawer } from './components/ConfigDrawer';
import { AnalysisResult, AnalysisStats } from './types';
import { Globe, AlertTriangle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { fallbackCategorizeDomains, buildMarkdown } from './utils/domainKnowledge';

const DEFAULT_SAMPLE_TEXT = `chase.com 12 accounts
coinbase.com 5 wallets
metamask.io 3 wallets
fidelity.com 2 accounts
paypal.com 4 accounts
aa.com 8 accounts
amazon.com 6 accounts
192.168.217.50:446`;

export default function App() {
  const [rawText, setRawText] = useState(DEFAULT_SAMPLE_TEXT);
  const [provider, setProvider] = useState<'gemini' | 'openai'>('gemini');
  const [model, setModel] = useState('gemini-3-flash-preview');
  const [apiKey, setApiKey] = useState('');
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [serverHasGeminiKey, setServerHasGeminiKey] = useState(true);
  const [lastDomains, setLastDomains] = useState<string[]>([]);

  // Check server health and load saved settings
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data && typeof data.hasGeminiKey === 'boolean') {
          setServerHasGeminiKey(data.hasGeminiKey);
        }
      })
      .catch((err) => {
        console.warn('Health check failed:', err);
      });

    try {
      const savedProvider = localStorage.getItem('domain_categorizer_provider');
      if (savedProvider === 'openai' || savedProvider === 'gemini') {
        setProvider(savedProvider);
      }
      const savedModel = localStorage.getItem('domain_categorizer_model');
      if (savedModel && savedModel.includes('gemini') && savedModel !== 'gemini-3.8-flash') {
        setModel(savedModel);
      } else {
        setModel('gemini-3-flash-preview');
      }
      const savedKey = localStorage.getItem('domain_categorizer_apikey');
      if (savedKey) {
        setApiKey(savedKey);
      }
    } catch {
      // ignore localStorage errors in iframe
    }
  }, []);

  // Save settings when changed
  useEffect(() => {
    try {
      localStorage.setItem('domain_categorizer_provider', provider);
      localStorage.setItem('domain_categorizer_model', model);
      if (apiKey) {
        localStorage.setItem('domain_categorizer_apikey', apiKey);
      } else {
        localStorage.removeItem('domain_categorizer_apikey');
      }
    } catch {
      // ignore
    }
  }, [provider, model, apiKey]);

  const handleAnalyze = async (
    domains: string[],
    metadataMap?: Record<string, { count: number; label?: string; occurrences: number }>,
    stats?: AnalysisStats
  ) => {
    if (domains.length === 0) {
      setErrorMessage('Please paste some text containing website domains or host IPs first.');
      return;
    }

    setLastDomains(domains);

    if (provider === 'openai' && !apiKey.trim()) {
      setErrorMessage('Please enter your OpenAI API Key in Settings to run the analysis with OpenAI.');
      setIsConfigOpen(true);
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          domains,
          domainMetadata: metadataMap,
          stats,
          provider,
          model,
          apiKey: apiKey.trim() || undefined,
        }),
      });

      clearTimeout(timeoutId);

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `Server responded with status ${response.status}`);
      }

      setResult(data);
      // Smooth scroll to results
      setTimeout(() => {
        const resultsEl = document.getElementById('analysis-results-section');
        if (resultsEl) {
          resultsEl.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } catch (err: any) {
      clearTimeout(timeoutId);
      console.warn('Analysis error encountered:', err);

      const isNetworkOrTimeout =
        err?.name === 'AbortError' ||
        err?.message?.includes('Load failed') ||
        err?.message?.includes('Failed to fetch') ||
        err?.message?.includes('NetworkError') ||
        err?.message?.includes('network');

      // If the network request failed or timed out, gracefully fulfill the analysis locally
      if (isNetworkOrTimeout || provider === 'gemini') {
        try {
          const fallbackCats = fallbackCategorizeDomains(domains, metadataMap);
          const categories = fallbackCats.map((cat, idx) => ({
            id: `cat-${idx}-${cat.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
            name: cat.name,
            description: cat.description,
            items: cat.items,
          }));
          const markdown = buildMarkdown(categories, stats);

          setResult({
            categories,
            markdown,
            totalDomains: domains.length,
            modelUsed: 'Domain Intelligence Engine (Auto-Fallback)',
            timestamp: new Date().toISOString(),
            fallbackUsed: true,
            note: isNetworkOrTimeout
              ? 'Categorized using built-in intelligence engine (the remote server connection took too long or was interrupted). You can re-run with AI at any time.'
              : err?.message || 'Categorized using built-in intelligence engine.',
            stats,
          });
          setErrorMessage(null);

          setTimeout(() => {
            const resultsEl = document.getElementById('analysis-results-section');
            if (resultsEl) {
              resultsEl.scrollIntoView({ behavior: 'smooth' });
            }
          }, 100);
          return;
        } catch (fallbackErr) {
          console.error('Client-side fallback failed:', fallbackErr);
        }
      }

      setErrorMessage(err.message || 'An error occurred during analysis. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50/50 text-zinc-900 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Header */}
      <Header
        onOpenConfig={() => setIsConfigOpen(true)}
        activeModel={model}
        provider={provider}
        hasCustomKey={Boolean(apiKey)}
      />

      {/* Main Content */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-8">
        {/* Intro */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold tracking-tight text-zinc-900 sm:text-3xl flex items-center space-x-2">
            <span>🌐 Website & App Categorizer</span>
          </h2>
          <p className="mt-1.5 text-sm text-zinc-600 max-w-2xl leading-relaxed">
            Paste your raw text, lists, or notes below to automatically extract and describe what every website, software, or app does.
          </p>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div
            id="error-alert-box"
            className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800 flex items-start space-x-3 shadow-xs"
          >
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold">Analysis Notice</p>
              <p className="mt-0.5 text-xs text-red-700 leading-relaxed">{errorMessage}</p>
            </div>
            <div className="flex items-center space-x-2 shrink-0">
              {lastDomains.length > 0 && (
                <button
                  type="button"
                  onClick={() => handleAnalyze(lastDomains)}
                  className="px-2.5 py-1 text-xs font-medium bg-red-600 hover:bg-red-700 text-white rounded-md transition-colors"
                >
                  Retry
                </button>
              )}
              <button
                type="button"
                onClick={() => setErrorMessage(null)}
                className="text-xs text-red-600 hover:text-red-900 font-medium"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Input Form Area */}
        <DomainInput
          rawText={rawText}
          setRawText={setRawText}
          onAnalyze={handleAnalyze}
          isLoading={isLoading}
          provider={provider}
          hasApiKey={Boolean(apiKey)}
          onOpenConfig={() => setIsConfigOpen(true)}
        />

        {/* Results Section */}
        {result && (
          <ResultsView
            result={result}
            onReanalyze={() => (lastDomains.length > 0 ? handleAnalyze(lastDomains) : undefined)}
          />
        )}
      </main>

      {/* Settings / Configuration Drawer */}
      <ConfigDrawer
        isOpen={isConfigOpen}
        onClose={() => setIsConfigOpen(false)}
        provider={provider}
        setProvider={setProvider}
        model={model}
        setModel={setModel}
        apiKey={apiKey}
        setApiKey={setApiKey}
        serverHasGeminiKey={serverHasGeminiKey}
      />

      {/* Footer */}
      <footer className="border-t border-zinc-200 py-6 text-center text-xs text-zinc-500 bg-white">
        <p>
          Website & App Categorizer • High-speed domain extraction and AI categorization
        </p>
      </footer>
    </div>
  );
}
