/**
 * Domain extraction and normalization utility
 * Accurately extracts domains, IPv4 hosts, URLs, and contextual quantities (e.g. "8 accounts", "6 sessions").
 * Guarantees precise site counts, deduplication, and file extension filtering.
 */

import { AnalysisStats } from '../types';

// Common non-domain extensions to ignore if parsed from filenames or log texts
const EXCLUDED_EXTENSIONS = new Set([
  'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico',
  'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt',
  'mp3', 'mp4', 'wav', 'zip', 'tar', 'gz', 'json', 'xml',
  'bin', 'exe', 'dmg', 'iso', 'log', 'sh', 'py', 'js', 'ts'
]);

export interface DomainMetadata {
  domain: string;
  count: number;
  label?: string;
  occurrences: number;
  rawLines?: string[];
}

export interface DomainExtractionResult {
  domains: string[];
  stats: AnalysisStats;
  metadataMap: Record<string, { count: number; label?: string; occurrences: number }>;
  items: DomainMetadata[];
}

/**
 * Extracts and normalizes domain names and IPv4 network hosts with comprehensive accounting.
 */
export function extractDomainsDetailed(rawText: string): DomainExtractionResult {
  if (!rawText || typeof rawText !== 'string') {
    return {
      domains: [],
      stats: {
        pastedLinesCount: 0,
        totalDetectedItems: 0,
        uniqueDomainsCount: 0,
        duplicateMentionsCount: 0,
        totalInstancesOrAccounts: 0,
      },
      metadataMap: {},
      items: [],
    };
  }

  const lines = rawText.split(/\r?\n/);
  let pastedLinesCount = 0;
  let totalDetectedItems = 0;
  let totalInstancesOrAccounts = 0;
  const uniqueMap = new Map<string, DomainMetadata>();

  // Regular expression matching:
  // 1. URLs or domain names with standard TLDs and optional port
  // 2. IPv4 host addresses (e.g. 192.168.217.50:446 or 10.0.4.12)
  const HOST_REGEX = /(?:https?:\/\/)?(?:www\.)?([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+(?::\d+)?)|(?:\b(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?\b)/gi;

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    pastedLinesCount++;

    const matches = Array.from(line.matchAll(HOST_REGEX));

    for (const match of matches) {
      let rawHost = match[0].toLowerCase().trim();
      // Normalize protocol, leading www., and URL paths
      rawHost = rawHost.replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/.*$/, '').trim();
      rawHost = rawHost.replace(/^\.+|\.+$/g, '');

      if (!rawHost) continue;

      // Check if it's an excluded file extension (e.g. file.txt, image.png)
      const parts = rawHost.split('.');
      const lastPart = parts[parts.length - 1].replace(/:\d+$/, '');
      if (EXCLUDED_EXTENSIONS.has(lastPart)) {
        continue;
      }

      totalDetectedItems++;

      // Extract account/session/quantity metadata from the line
      // E.g. "aa.com 8 accounts" -> count: 8, label: "8 accounts"
      const remaining = line.replace(match[0], ' ').trim();
      let count = 1;
      let label: string | undefined = undefined;

      // Pattern 1: Number with descriptor (accounts, sessions, checkouts, logins, keys, tickets, users)
      const countWithWord = remaining.match(
        /\b(\d+)\s*(accounts?|sessions?|checkouts?|keys?|tickets?|logins?|users?|profiles?|records?|instances?|items?|times?)\b/i
      );

      if (countWithWord) {
        count = parseInt(countWithWord[1], 10) || 1;
        label = countWithWord[0].trim();
      } else {
        // Pattern 2: Multiplier or count prefix (e.g. x 5, count: 4, # 10, - 8)
        const multiplier = remaining.match(/(?:^|\s)(?:x|qty|count|#|×|:|-)\s*(\d+)\b/i);
        if (multiplier) {
          count = parseInt(multiplier[1], 10) || 1;
          label = `${count} accounts/items`;
        } else {
          // Pattern 3: Standalone number at end of line (e.g. "amazon.com 6")
          const standalone = remaining.match(/\b(\d+)\s*$/);
          if (standalone) {
            const num = parseInt(standalone[1], 10);
            if (num > 0 && num < 1000000) {
              count = num;
              label = `${num} accounts/items`;
            }
          }
        }
      }

      totalInstancesOrAccounts += count;

      if (!uniqueMap.has(rawHost)) {
        uniqueMap.set(rawHost, {
          domain: rawHost,
          count: count,
          label: label,
          occurrences: 1,
          rawLines: [line],
        });
      } else {
        const existing = uniqueMap.get(rawHost)!;
        existing.occurrences++;
        existing.count += count;
        if (label && !existing.label) {
          existing.label = label;
        } else if (label && existing.label) {
          existing.label = `${existing.count} total accounts/items`;
        }
        existing.rawLines?.push(line);
      }
    }
  }

  const domains = Array.from(uniqueMap.keys());
  const uniqueCount = domains.length;
  const duplicateMentionsCount = Math.max(0, totalDetectedItems - uniqueCount);

  const metadataMap: Record<string, { count: number; label?: string; occurrences: number }> = {};
  for (const [dom, meta] of uniqueMap.entries()) {
    metadataMap[dom] = {
      count: meta.count,
      label: meta.label,
      occurrences: meta.occurrences,
    };
  }

  return {
    domains,
    stats: {
      pastedLinesCount,
      totalDetectedItems,
      uniqueDomainsCount: uniqueCount,
      duplicateMentionsCount,
      totalInstancesOrAccounts: totalInstancesOrAccounts > 0 ? totalInstancesOrAccounts : uniqueCount,
    },
    metadataMap,
    items: Array.from(uniqueMap.values()),
  };
}

/**
 * Basic domain extractor for backward compatibility, returns string array of unique domains/hosts.
 */
export function extractDomains(rawText: string): string[] {
  return extractDomainsDetailed(rawText).domains;
}
