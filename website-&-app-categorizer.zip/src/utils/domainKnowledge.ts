import { TwoFactorMethodType } from '../types';

export interface FallbackItem {
  domain: string;
  siteSubType: string;
  description: string;
  tags: string[];
  pastedCount?: number;
  pastedLabel?: string;
  rawOccurrences?: number;
  rewards: {
    hasRewardsOrPoints: boolean;
    canEarn: boolean;
    canWithdrawOrRedeem: boolean;
    rewardsDetails: string;
    hasGiftCards: boolean;
    giftCardDetails: string;
    isBankOrFinancial: boolean;
    financialSubType?: string;
    financialDetails?: string;
    supportsPhone2FA: string;
    supportsEmail2FA: string;
    twoFactorType: TwoFactorMethodType;
    twoFactorDetails: string;
    loginVerificationGuide: string;
  };
}

export interface FallbackCategory {
  name: string;
  description: string;
  items: FallbackItem[];
}

export const KNOWN_DOMAINS: Record<
  string,
  {
    category: string;
    siteSubType: string;
    description: string;
    tags: string[];
    rewards?: Partial<FallbackItem['rewards']>;
  }
> = {
  // Retail & Commercial Banks
  'chase.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Retail & Commercial Bank',
    description:
      'JPMorgan Chase full-service retail and commercial bank offering checking/savings accounts, credit cards, mortgages, auto loans, and Chase Ultimate Rewards.',
    tags: ['Retail Bank', 'Checking & Savings', 'Credit Cards'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Chase Ultimate Rewards points can be earned on card spending and redeemed for cash back, direct deposit, travel, or airline/hotel partner transfers.',
      hasGiftCards: true,
      giftCardDetails: 'Redeem Ultimate Rewards points for merchant gift cards or purchase retail e-gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Retail & Commercial Bank',
      financialDetails:
        'Traditional FDIC-insured bank: Holds checking and savings cash deposits, issues Visa/Mastercard credit & debit cards, supports Zelle P2P transfers, domestic/international wire transfers, ACH bank transfers, and self-directed investing via J.P. Morgan Wealth Management.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Supports both Phone (SMS/voice call) and Email security codes. Primary prompt defaults to mobile SMS; registered email is available as an alternative verification channel.',
      loginVerificationGuide:
        '1. Enter User ID & Password. 2. When prompted by the Security Challenge, select delivery: Phone SMS, automated voice call, or registered email. 3. Enter the 8-digit temporary code received within 10 minutes to complete login.',
    },
  },
  'bankofamerica.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Retail & Commercial Bank',
    description:
      'Bank of America consumer and business bank providing checking/savings accounts, credit cards, home loans, and Merrill Edge investment integration.',
    tags: ['Retail Bank', 'Lending', 'Wealth Management'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Preferred Rewards and credit card cash rewards can be earned and cashed out directly to bank accounts.',
      hasGiftCards: false,
      giftCardDetails: 'Credit card rewards can occasionally be redeemed for retail gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Retail & Commercial Bank',
      financialDetails:
        'Full-service FDIC-insured retail bank: Offers personal/business checking & savings, ACH/wire transfers, Zelle instant transfers, credit cards, and connected Merrill Lynch investment brokerage accounts.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Bank of America SafePass supports both Phone SMS/voice call codes and Email authorization codes for unrecognized browsers or high-value transactions.',
      loginVerificationGuide:
        '1. Enter Online ID & Passcode. 2. If challenged, select "Text me a code", "Call me", or "Send code to email". 3. Receive a 6-digit SafePass code and enter it to authorize the browser/device.',
    },
  },
  'wellsfargo.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Retail & Commercial Bank',
    description:
      'Wells Fargo consumer and commercial bank offering checking and savings accounts, residential mortgages, auto loans, and WellsTrade brokerage.',
    tags: ['Retail Bank', 'Mortgages', 'Checking & Savings'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Wells Fargo Rewards points can be earned on purchases and redeemed for statement credit or cash withdrawal at ATMs.',
      hasGiftCards: true,
      giftCardDetails: 'Points can be redeemed for gift cards from major merchants.',
      isBankOrFinancial: true,
      financialSubType: 'Retail & Commercial Bank',
      financialDetails:
        'Traditional national retail bank: Provides checking/savings accounts, debit/credit cards, ACH and wire transfers, Zelle payments, mortgage servicing, and WellsTrade investment accounts.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'No',
      twoFactorType: 'Phone Only',
      twoFactorDetails:
        'Wells Fargo Advanced Access requires Phone SMS or automated phone call verification. Email OTP is NOT supported for primary 2FA login verification.',
      loginVerificationGuide:
        '1. Enter username and password. 2. Wells Fargo prompts for Advanced Access phone verification. 3. System sends a 6-digit code via SMS or voice call to the phone number on file. 4. Note: Email cannot be selected as a login 2FA destination for security policy reasons.',
    },
  },
  'citi.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Retail Bank & Credit Card Issuer',
    description:
      'Citibank global consumer bank providing checking/savings accounts, personal loans, wealth management, and Citi ThankYou Rewards credit cards.',
    tags: ['Retail Bank', 'Credit Cards', 'Global Banking'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Citi ThankYou points earned on eligible card transactions, redeemable for cash back, travel, and direct deposit.',
      hasGiftCards: true,
      giftCardDetails: 'Supports redeeming ThankYou Points for hundreds of retail gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Retail Bank & Credit Card Issuer',
      financialDetails:
        'Global retail bank and major credit card issuer: Offers FDIC checking/savings accounts, credit lines, international currency wires, ACH transfers, and Citi Personal Wealth Management.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Citi supports both mobile phone SMS/voice OTP codes and email identification codes when verifying new devices.',
      loginVerificationGuide:
        '1. Enter User ID & Password. 2. If 2FA triggers, choose between SMS text message to phone or email verification code. 3. Input the 6-digit one-time PIN to access banking dashboard.',
    },
  },
  'capitalone.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Retail Bank & Credit Card Issuer',
    description:
      'Capital One digital-first bank offering 360 Checking/Savings accounts, auto financing, and Venture/Quicksilver rewards credit cards.',
    tags: ['Retail Bank', 'Credit Cards', 'Auto Loans'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Venture miles and cash back earned on purchases, redeemable for travel credit, check, or statement withdrawal.',
      hasGiftCards: true,
      giftCardDetails: 'Redeem miles and cash rewards for merchant gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Retail Bank & Credit Card Issuer',
      financialDetails:
        'FDIC-insured consumer bank & card lender: Provides high-yield 360 Savings, checking accounts, virtual credit card numbers (Eno), ACH bank transfers, Zelle, and auto loan management.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Capital One supports both Phone number SMS/call codes, Email OTP codes, and mobile app push notifications ("Swipe to confirm").',
      loginVerificationGuide:
        '1. Enter Username & Password. 2. Choose verification method: SMS to phone, voice call, email temporary code, or Capital One Mobile App push prompt. 3. Confirm 6-digit code or tap approval in the app.',
    },
  },
  'americanexpress.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Credit Card Issuer & High-Yield Bank',
    description:
      'American Express charge/credit card issuer, high-yield personal savings bank, business lines of credit, and Membership Rewards portal.',
    tags: ['Credit Cards', 'Charge Cards', 'Banking'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Membership Rewards points earned per dollar spent, redeemable for statement credit, travel bookings, or airline partner points.',
      hasGiftCards: true,
      giftCardDetails: 'Offers point redemptions for gift cards from retail, dining, and travel partners.',
      isBankOrFinancial: true,
      financialSubType: 'Credit Card Issuer & Online Bank',
      financialDetails:
        'Charge/credit card issuer & online bank: Issues Platinum/Gold consumer & corporate cards, Amex High-Yield Savings and rewards checking accounts, personal loans, and Amex Send & Split P2P payments.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'American Express 2-step verification supports both Phone SMS/call codes and Email verification codes.',
      loginVerificationGuide:
        '1. Enter User ID & Password. 2. Amex prompts "Confirm your identity". 3. Select registered mobile number for SMS or registered email address. 4. Enter the 6-digit numeric code to complete sign-in.',
    },
  },
  'amex.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Credit Card Issuer & High-Yield Bank',
    description:
      'American Express cardmember portal for managing credit/charge cards, high-yield savings accounts, and Membership Rewards.',
    tags: ['Credit Cards', 'Banking', 'Rewards'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Membership Rewards points redeemable for statement credits, travel, or gift cards.',
      hasGiftCards: true,
      giftCardDetails: 'Redeem Membership Rewards for retail gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Credit Card Issuer & Online Bank',
      financialDetails:
        'Cardmember & banking portal for American Express credit cards, business lines of credit, and FDIC-insured high-yield savings accounts.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports both phone SMS/call and email 2FA verification.',
      loginVerificationGuide:
        '1. Enter credentials. 2. Choose phone SMS or email code. 3. Input 6-digit security code to authenticate.',
    },
  },
  'usbank.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Retail & Commercial Bank',
    description:
      'U.S. Bank personal and business banking platform offering checking, savings, mortgages, wealth management, and Altitude rewards cards.',
    tags: ['Retail Bank', 'Mortgages', 'Credit Cards'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'U.S. Bank Altitude points and cash back redeemable for deposit, statement credit, or travel.',
      hasGiftCards: true,
      giftCardDetails: 'Points can be redeemed for retail gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Retail & Commercial Bank',
      financialDetails:
        'Full-service commercial and consumer bank: Supports checking/savings, ACH transfers, Zelle, wire transfers, credit cards, and U.S. Bancorp Investments.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports SMS/voice OTP codes to registered phones and email verification codes.',
      loginVerificationGuide:
        '1. Enter username and password. 2. Choose SMS code or email code verification. 3. Enter 6-digit security code.',
    },
  },
  'pnc.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Retail & Commercial Bank',
    description:
      'PNC Bank online banking with Virtual Wallet checking/savings, mortgages, personal loans, and cash rewards credit cards.',
    tags: ['Retail Bank', 'Virtual Wallet', 'Lending'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'PNC points and Cash Rewards redeemable directly into Virtual Wallet or statement balance.',
      hasGiftCards: true,
      giftCardDetails: 'Redeem points for gift cards inside the PNC rewards portal.',
      isBankOrFinancial: true,
      financialSubType: 'Retail & Commercial Bank',
      financialDetails:
        'Retail bank featuring Virtual Wallet (combined checking, short-term reserve, and long-term savings), ACH/wires, Zelle, and credit cards.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports Phone SMS/call OTP and Email verification codes.',
      loginVerificationGuide:
        '1. Enter User ID & Password. 2. Select phone SMS/voice or email verification code. 3. Enter 6-digit code to access Virtual Wallet.',
    },
  },
  'discover.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Credit Card Issuer & Online Bank',
    description:
      'Discover Financial Services offering Cashback Bonus credit cards, cashback debit checking, high-yield online savings, and personal/student loans.',
    tags: ['Credit Cards', 'Online Bank', 'Cashback'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Discover Cashback Bonus never expires and can be withdrawn to any bank account at any amount.',
      hasGiftCards: true,
      giftCardDetails: 'Redeem Cashback Bonus for partner gift cards with an added 5%–20% bonus value.',
      isBankOrFinancial: true,
      financialSubType: 'Credit Card Issuer & Online Bank',
      financialDetails:
        'Online bank and credit card network: Issues Discover cards, FDIC-insured online checking (with 1% debit cashback) and high-yield savings accounts, plus ACH transfers and Zelle.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports both Phone SMS/voice call OTP and Email security code verification.',
      loginVerificationGuide:
        '1. Enter User ID & Password. 2. Select SMS text to phone or Email verification code. 3. Enter the 6-digit code to sign in.',
    },
  },
  'navyfederal.org': {
    category: 'Banking & Financial Services',
    siteSubType: 'Federal Credit Union (Military & Families)',
    description:
      'Navy Federal Credit Union providing checking/savings accounts, VA mortgages, auto loans, and Flagship/cashRewards credit cards for military members and families.',
    tags: ['Credit Union', 'Military Banking', 'Loans'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Member Deals and credit card points/cashback can be redeemed directly into savings or checking.',
      hasGiftCards: true,
      giftCardDetails: 'Points can be redeemed for Visa prepaid and retail gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Credit Union (Banking & Lending)',
      financialDetails:
        'Member-owned federal credit union: Provides checking, share savings, certificates, VA home loans, auto loans, credit cards, ACH/wire transfers, and Zelle.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports 2-Step Verification via SMS text, voice call, email passcode, or mobile app push.',
      loginVerificationGuide:
        '1. Enter Username & Password. 2. Choose SMS text code, Email code, or Mobile App push notification. 3. Complete verification.',
    },
  },
  'chime.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Neobank & Mobile Banking App',
    description:
      'Chime financial technology app offering fee-free mobile checking, high-yield savings, SpotMe overdraft protection, and Credit Builder secured Visa cards.',
    tags: ['Neobank', 'Mobile Banking', 'Debit & Credit Builder'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Cash back offers on select debit/credit purchases (Chime Deals) credited directly to checking balance.',
      hasGiftCards: false,
      giftCardDetails: 'Direct cash balance credits rather than gift card store.',
      isBankOrFinancial: true,
      financialSubType: 'Neobank / Mobile Banking App',
      financialDetails:
        'Consumer neobank (FDIC-insured via partner banks Bancorp/Stride): Provides checking account with routing/account numbers, early direct deposit, Pay Anyone P2P transfers, Visa debit card, and Credit Builder card.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Primary login requires SMS code to registered mobile number, with email confirmation links for unrecognized devices.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Enter the 6-digit SMS verification code sent to your phone. 3. Confirm via email link if signing in from a new browser.',
    },
  },
  'sofi.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Digital Bank, Lending & Investment App',
    description:
      'SoFi all-in-one personal finance app combining FDIC checking & high-yield savings, student/personal loans, credit cards, and stock/ETF investing.',
    tags: ['Digital Bank', 'Investing', 'Loans'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'SoFi Member Rewards points can be redeemed for cash into SoFi Checking/Savings, fractional stock shares, or loan payments.',
      hasGiftCards: false,
      giftCardDetails: 'Focuses on direct cash or fractional share redemptions.',
      isBankOrFinancial: true,
      financialSubType: 'All-in-One Digital Bank, Lending & Brokerage',
      financialDetails:
        'Chartered national bank & brokerage: Combines high-yield checking/savings (ACH/wires/Zelle), personal/student/mortgage loans, and SoFi Invest (stocks, ETFs, IRAs, robo-advisor).',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports SMS codes, authenticator apps (TOTP), and email verification codes.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Enter 6-digit 2FA code from SMS or Authenticator app (or choose email fallback if enabled).',
    },
  },

  // Crypto Wallets, Exchanges & Web3
  'coinbase.com': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Crypto Exchange & Custodial Wallet',
    description:
      'Leading regulated cryptocurrency exchange and custodial wallet for buying, selling, staking, and storing Bitcoin, Ethereum, USDC, and 250+ digital assets.',
    tags: ['Crypto Exchange', 'Crypto Wallet', 'Web3'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Earn crypto via Coinbase Learning Rewards, USDC rewards, staking yields, and up to 4% crypto back with Coinbase Card.',
      hasGiftCards: true,
      giftCardDetails: 'Coinbase gift cards available; crypto balances can be spent on retail gift cards via partner integrations.',
      isBankOrFinancial: true,
      financialSubType: 'Crypto Exchange & Custodial Wallet',
      financialDetails:
        'Cryptocurrency exchange & fiat-to-crypto gateway: Users can link bank accounts (ACH/wire/FedNow), debit cards, or PayPal to buy/sell crypto, hold USD/USDC, stake assets, and send/withdraw cryptocurrency on-chain to external self-custody wallets.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Supports Passkeys, Security Keys, Authenticator apps, Phone SMS codes, plus mandatory Email device confirmation for new IP addresses.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Complete 2FA via Authenticator app, SMS code, or Passkey. 3. If logging in from an unrecognized device/IP, click the confirmation link sent to your email inbox.',
    },
  },
  'binance.com': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Crypto Exchange & Trading Platform',
    description:
      'Global cryptocurrency exchange for spot and derivatives trading, Web3 wallet management, crypto staking (Binance Earn), and P2P fiat-to-crypto exchange.',
    tags: ['Crypto Exchange', 'Trading', 'Crypto Wallet'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Binance Earn staking yields, Launchpool token rewards, and Rewards Hub vouchers redeemable to spot wallet.',
      hasGiftCards: true,
      giftCardDetails: 'Binance Gift Card allows sending and redeeming cryptocurrency gift codes globally with zero fees.',
      isBankOrFinancial: true,
      financialSubType: 'Cryptocurrency Exchange & Web3 Wallet',
      financialDetails:
        'Centralized crypto exchange & custodial/Web3 wallet: Supports spot/margin/futures trading, P2P fiat trading, Binance Pay merchant transfers, and multi-chain cryptocurrency deposits and withdrawals.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Multi-factor security often requires BOTH Email verification code and Phone SMS / Authenticator App code for login and crypto withdrawals.',
      loginVerificationGuide:
        '1. Enter email/phone and password. 2. Complete security puzzle. 3. Enter 6-digit verification code from Authenticator app, SMS, and/or Email.',
    },
  },
  'kraken.com': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Crypto Exchange & Staking Platform',
    description:
      'Cryptocurrency exchange and custodial platform offering fiat-to-crypto trading, margin/futures, on-chain staking, and institutional custody.',
    tags: ['Crypto Exchange', 'Bitcoin', 'Staking'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'On-chain and opt-in staking rewards paid weekly in crypto and immediately withdrawable.',
      hasGiftCards: false,
      giftCardDetails: 'Direct crypto and fiat exchange without retail gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Cryptocurrency Exchange & Custody',
      financialDetails:
        'Crypto exchange & fiat ramp: Supports USD/EUR/GBP bank wire & ACH deposits, spot & pro crypto trading, staking yields, and direct blockchain withdrawals to external wallets.',
      supportsPhone2FA: 'No',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Email Only',
      twoFactorDetails:
        'Kraken enforces Authenticator App (TOTP) or Hardware FIDO2 Passkey for 2FA plus Email new-device approval links (SMS 2FA is disabled for security against SIM swaps).',
      loginVerificationGuide:
        '1. Enter username and password. 2. Enter Authenticator 2FA code or Passkey. 3. Approve new device login via the security code sent to your registered email.',
    },
  },
  'crypto.com': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Crypto Exchange, Wallet & Visa Card',
    description:
      'Cryptocurrency trading platform, DeFi wallet ecosystem, and metal Visa prepaid card with CRO crypto cashback rewards.',
    tags: ['Crypto Exchange', 'Crypto Visa Card', 'DeFi Wallet'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Earn up to 5% CRO cashback on Visa card spending plus Crypto Earn yield on staked tokens.',
      hasGiftCards: true,
      giftCardDetails: 'Crypto.com Pay lets users purchase gift cards for 150+ brands using crypto with up to 10% cashback.',
      isBankOrFinancial: true,
      financialSubType: 'Crypto Exchange, Fiat Wallet & Prepaid Visa',
      financialDetails:
        'Combined crypto exchange, fiat wallet (ACH/SEPA bank transfers), DeFi wallet connector, and spendable Visa card funded by crypto or fiat.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Uses Magic Link email login combined with SMS phone verification and TOTP authenticator app codes.',
      loginVerificationGuide:
        '1. Enter email address. 2. Click magic sign-in link in email. 3. Enter SMS passcode sent to phone and/or 6-digit Authenticator code.',
    },
  },
  'metamask.io': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Self-Custody Crypto & Web3 Wallet',
    description:
      'Leading non-custodial Web3 cryptocurrency wallet for Ethereum and EVM blockchains, supporting token swaps, NFT storage, staking, and DeFi dApp connections.',
    tags: ['Crypto Wallet', 'Self-Custody', 'DeFi & Web3'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Earn ETH staking yields directly through MetaMask Portfolio liquid/validator staking.',
      hasGiftCards: false,
      giftCardDetails: 'Self-custody blockchain wallet without native retail gift card store.',
      isBankOrFinancial: true,
      financialSubType: 'Self-Custody Crypto Wallet (DeFi / Web3)',
      financialDetails:
        'Non-custodial cryptocurrency wallet: Users control their own 12-word Secret Recovery Phrase and private keys to hold, swap, bridge, buy/sell (via fiat on-ramps), and send ETH, ERC-20 tokens, and NFTs across EVM chains.',
      supportsPhone2FA: 'N/A',
      supportsEmail2FA: 'N/A',
      twoFactorType: 'App/Security Key',
      twoFactorDetails:
        'Decentralized self-custody wallet secured locally via wallet password, 12-word Secret Recovery Phrase, or connected Ledger/Trezor hardware wallet.',
      loginVerificationGuide:
        '1. Unlock browser extension or mobile app with local wallet password/biometrics, or import using the 12-word Secret Recovery Phrase.',
    },
  },
  'phantom.app': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Self-Custody Multi-Chain Crypto Wallet',
    description:
      'Non-custodial Web3 cryptocurrency wallet built for Solana, Ethereum, Bitcoin, and Polygon with built-in token swaps, NFT management, and SOL staking.',
    tags: ['Crypto Wallet', 'Solana & ETH', 'Self-Custody'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Supports native Solana (SOL) staking inside the wallet to earn validator yield.',
      hasGiftCards: false,
      giftCardDetails: 'Self-custody crypto wallet without gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Self-Custody Crypto Wallet (Solana / ETH / BTC)',
      financialDetails:
        'Self-custody Web3 wallet: Stores private keys locally for holding, swapping, staking, and transferring Solana, Bitcoin, Ethereum, and Polygon tokens and NFTs without a central bank.',
      supportsPhone2FA: 'N/A',
      supportsEmail2FA: 'N/A',
      twoFactorType: 'App/Security Key',
      twoFactorDetails: 'Secured via local device password/biometrics, 12/24-word recovery phrase, or Ledger hardware key.',
      loginVerificationGuide:
        '1. Open Phantom extension/app and unlock with password/FaceID, or restore wallet using the Secret Recovery Phrase.',
    },
  },
  'trustwallet.com': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Self-Custody Multi-Chain Crypto Wallet',
    description:
      'Multi-chain self-custody cryptocurrency and Web3 wallet supporting 100+ blockchains, in-wallet staking, cross-chain swaps, and dApp browsing.',
    tags: ['Crypto Wallet', 'Multi-Chain', 'Self-Custody'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'In-app crypto staking for BNB, ETH, SOL, ATOM, and 20+ proof-of-stake coins.',
      hasGiftCards: false,
      giftCardDetails: 'Self-custody crypto wallet.',
      isBankOrFinancial: true,
      financialSubType: 'Self-Custody Crypto Wallet',
      financialDetails:
        'Non-custodial mobile & browser crypto wallet: Gives users full control of private keys to store, stake, swap, and send Bitcoin, Ethereum, BNB, stablecoins, and NFTs.',
      supportsPhone2FA: 'N/A',
      supportsEmail2FA: 'N/A',
      twoFactorType: 'App/Security Key',
      twoFactorDetails: 'Secured via 12-word recovery phrase, passcode, or encrypted cloud backup.',
      loginVerificationGuide:
        '1. Unlock app with PIN/biometrics or restore multi-coin wallet via 12-word Secret Phrase.',
    },
  },
  'blockchain.com': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Crypto Wallet & Exchange',
    description:
      'Cryptocurrency platform providing both a self-custody DeFi wallet and a custodial trading/rewards account for Bitcoin, Ethereum, and stablecoins.',
    tags: ['Crypto Wallet', 'Bitcoin', 'Crypto Exchange'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Earn passive crypto rewards on eligible digital assets held in the Rewards account.',
      hasGiftCards: false,
      giftCardDetails: 'No retail gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Hybrid Crypto Wallet & Exchange',
      financialDetails:
        'Provides both non-custodial private-key crypto wallets and custodial trading accounts with bank/card fiat on-ramps and on-chain crypto transfers.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Requires email device authorization link plus SMS 2FA or Authenticator app code to access wallet.',
      loginVerificationGuide:
        '1. Enter Wallet ID or Email and password. 2. Click the "Authorize Log In" link sent to your email. 3. Enter 6-digit SMS or Authenticator 2FA code.',
    },
  },
  'ledger.com': {
    category: 'Crypto Wallets, Exchanges & Web3',
    siteSubType: 'Hardware Crypto Wallet & Cold Storage',
    description:
      'Hardware cryptocurrency wallet manufacturer (Ledger Nano / Stax) and Ledger Live companion app for offline cold-storage security of digital assets.',
    tags: ['Hardware Wallet', 'Cold Storage', 'Crypto Security'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Ledger Live allows staking ETH, SOL, DOT, and ATOM while keeping private keys offline on the hardware device.',
      hasGiftCards: true,
      giftCardDetails: 'Sells Ledger gift cards and integrates Bitrefill in Ledger Live to buy gift cards with crypto.',
      isBankOrFinancial: true,
      financialSubType: 'Hardware Crypto Wallet (Cold Storage)',
      financialDetails:
        'Physical cold-storage crypto security device & management portal: Stores private keys offline on a secure element chip; every outgoing crypto transaction must be physically approved on the Ledger device.',
      supportsPhone2FA: 'N/A',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'App/Security Key',
      twoFactorDetails: 'Wallet transactions require physical hardware key confirmation; e-commerce store uses email login.',
      loginVerificationGuide:
        '1. Connect physical Ledger device via USB/Bluetooth and enter PIN on device. 2. For Ledger Recover or store orders, verify via email code.',
    },
  },

  // Investment, Stock Brokerages & Wealth Management
  'fidelity.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Investment Brokerage & Retirement Platform',
    description:
      'Fidelity Investments full-service brokerage for stock/ETF/options trading, 401(k) & IRA retirement accounts, Cash Management accounts, and wealth advisory.',
    tags: ['Investment Brokerage', 'Retirement & 401k', 'Stock Trading'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Fidelity Rewards Visa Signature card earns unlimited 2% cash back deposited directly into eligible Fidelity brokerage or cash accounts.',
      hasGiftCards: false,
      giftCardDetails: 'Direct cash investment deposit rather than gift card redemptions.',
      isBankOrFinancial: true,
      financialSubType: 'Stock Brokerage, Retirement (401k/IRA) & Cash Management',
      financialDetails:
        'Major investment brokerage & wealth custodian: Holds individual stock/ETF portfolios, mutual funds, 401(k)/Rollover/Roth IRAs, Fidelity Crypto, and Cash Management accounts (with checkwriting, debit card, and ACH/wire transfers).',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'No',
      twoFactorType: 'Phone Only',
      twoFactorDetails:
        'Fidelity 2FA enforces Phone number SMS/call, Fidelity Mobile App push notification, or Authenticator app. Email OTP is disabled for login security.',
      loginVerificationGuide:
        '1. Enter username and password. 2. Fidelity triggers 2FA security prompt. 3. Approve push notification in Fidelity app, or receive 6-digit code via SMS/voice call to phone on file. 4. Email 2FA is not supported for login verification.',
    },
  },
  'robinhood.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Stock, Options & Crypto Trading Brokerage',
    description:
      'Commission-free investment and trading app for stocks, ETFs, options, IRAs with match, high-yield cash sweep, and cryptocurrency trading.',
    tags: ['Stock Trading', 'Crypto Trading', 'Brokerage App'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Robinhood Gold Card earns 3% cash back across all categories, redeemable directly into the investment brokerage cash balance.',
      hasGiftCards: false,
      giftCardDetails: 'Rewards convert directly to investable brokerage cash.',
      isBankOrFinancial: true,
      financialSubType: 'Retail Stock, Options & Crypto Brokerage',
      financialDetails:
        'Investment brokerage & crypto app: Allows trading US stocks, ETFs, options, and crypto (BTC, ETH, SOL), holds IRA retirement accounts, offers high-yield cash sweep, and links to external banks via ACH or instant debit card transfers.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Supports Mobile App device approval prompts, SMS phone codes, Authenticator apps, and backup email verification.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Approve login prompt on the Robinhood mobile app, or select "Need help?" to verify via SMS code sent to your phone number.',
    },
  },
  'schwab.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Investment Brokerage & Investor Bank',
    description:
      'Charles Schwab investment brokerage and bank offering stock/ETF/options trading (thinkorswim), IRAs, wealth management, and Schwab Bank Investor Checking.',
    tags: ['Investment Brokerage', 'Stock Trading', 'Investor Bank'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Schwab Investor Card from Amex earns 1.5% cash back automatically deposited into a Schwab brokerage account.',
      hasGiftCards: false,
      giftCardDetails: 'Direct brokerage cash sweep deposits.',
      isBankOrFinancial: true,
      financialSubType: 'Full-Service Investment Brokerage & Bank',
      financialDetails:
        'Brokerage & FDIC bank: Provides stock/bond/options trading, thinkorswim platform, IRAs, domestic/international wire transfers, ACH links, and Schwab Bank High Yield Investor Checking.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'No',
      twoFactorType: 'Phone Only',
      twoFactorDetails: 'Enforces Phone SMS/voice call OTP, Schwab Mobile App push notification, or Symantec VIP security token.',
      loginVerificationGuide:
        '1. Enter Login ID and password. 2. Approve push notification on Schwab Mobile app or choose SMS/voice call to receive a 6-digit security code.',
    },
  },
  'vanguard.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Investment Management & Retirement Brokerage',
    description:
      'Vanguard investment platform specializing in low-cost index funds, ETFs, mutual funds, 401(k)/IRA retirement accounts, and Cash Plus accounts.',
    tags: ['Investments', 'Index Funds & ETFs', 'Retirement'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'Low-fee investment custodian rather than a consumer points program.',
      hasGiftCards: false,
      giftCardDetails: 'No gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Investment & Retirement Custodian (ETFs / Mutual Funds / IRAs)',
      financialDetails:
        'Wealth & retirement investment firm: Holds long-term brokerage portfolios, Roth/Traditional IRAs, employer 401(k) plans, and Vanguard Cash Plus high-yield accounts with ACH bank settlement.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'No',
      twoFactorType: 'Phone Only',
      twoFactorDetails: 'Requires Phone SMS/voice OTP code, Vanguard app push prompt, or hardware security key.',
      loginVerificationGuide:
        '1. Enter username and password. 2. Receive 6-digit code via SMS text or voice call to your registered phone number.',
    },
  },
  'etrade.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Stock & Options Brokerage & Bank',
    description:
      'E*TRADE from Morgan Stanley online brokerage for trading stocks, options, futures, mutual funds, employee stock plans, and high-yield savings.',
    tags: ['Investment Brokerage', 'Options Trading', 'Stock Plans'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'Brokerage platform focused on trading and cash yields.',
      hasGiftCards: false,
      giftCardDetails: 'No gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Online Stock/Options Brokerage & Morgan Stanley Private Bank',
      financialDetails:
        'Brokerage & corporate stock plan portal: Manages retail stock/options accounts, corporate RSUs/ESPP equity plans, IRAs, and Morgan Stanley Private Bank high-yield savings and checking accounts.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'No',
      twoFactorType: 'Phone Only',
      twoFactorDetails: 'Supports Phone SMS/voice codes and VIP Access authenticator app.',
      loginVerificationGuide:
        '1. Enter User ID and password. 2. Receive verification code via SMS/call or enter VIP Access authenticator security code.',
    },
  },
  'webull.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Stock, Options & ETF Trading Brokerage',
    description:
      'Electronic trading brokerage platform offering commission-free stocks, options, ETFs, fractional shares, IRAs, and cash management interest.',
    tags: ['Stock Trading', 'Options', 'Brokerage'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Promotional fractional stock rewards for deposits and referrals, sellable for withdrawable cash.',
      hasGiftCards: false,
      giftCardDetails: 'Rewards are issued as free fractional shares.',
      isBankOrFinancial: true,
      financialSubType: 'Active Trading Brokerage (Stocks / Options / Futures)',
      financialDetails:
        'Retail trading brokerage: Provides margin and cash brokerage accounts, IRA retirement accounts, 5% APY cash management sweep, and ACH/wire bank funding and withdrawals.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports both Phone SMS OTP and Email verification codes alongside a 6-digit trading PIN.',
      loginVerificationGuide:
        '1. Sign in with phone number or email + password. 2. Enter 6-digit OTP sent via SMS or Email. 3. Enter 6-digit Trading Password to unlock trade execution or withdrawals.',
    },
  },

  // Digital Wallets, P2P Payments, Remittance & BNPL
  'paypal.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Digital Payment Wallet & P2P Money Transfer',
    description:
      'Global digital wallet and online payments platform for peer-to-peer money transfers, merchant checkout, PayPal Balance savings, and crypto buying.',
    tags: ['Digital Wallet', 'P2P Payments', 'FinTech'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Earn PayPal Rewards points and cashback on shopping and cash out directly to PayPal balance or linked bank.',
      hasGiftCards: true,
      giftCardDetails: 'PayPal Digital Gifts store allows buying and sending digital gift cards for major brands.',
      isBankOrFinancial: true,
      financialSubType: 'Digital Payment Wallet, P2P Transfers & Crypto Custody',
      financialDetails:
        'Digital wallet & payment hub: Holds USD/multi-currency balances, links to external bank accounts and credit/debit cards, sends instant P2P money transfers, offers Pay in 4 (BNPL), PayPal Debit/Credit cards, and in-app Crypto (BTC, ETH, PYUSD) buying and transfers.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'PayPal supports both Phone SMS codes and Email one-time passcode links, in addition to Authenticator app (TOTP) and passkeys.',
      loginVerificationGuide:
        '1. Enter email address. 2. Choose login via password + 2FA or passwordless One-Time Code. 3. Select SMS text code or Email verification link/code. 4. Complete verification to access wallet.',
    },
  },
  'venmo.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'P2P Payment Wallet & Social Money App',
    description:
      'Peer-to-peer mobile payment service (owned by PayPal) for splitting bills, sending money to friends, shopping with Venmo Debit/Credit cards, and buying crypto.',
    tags: ['P2P Payments', 'Digital Wallet', 'Mobile Money'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Venmo Credit Card earns up to 3% cash back automatically credited to the Venmo balance or auto-invested in crypto.',
      hasGiftCards: false,
      giftCardDetails: 'Sends direct P2P cash with digital gift wrap rather than merchant gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'Peer-to-Peer (P2P) Digital Payment Wallet',
      financialDetails:
        'P2P money transfer & digital wallet: Holds spendable cash balance, connects to bank accounts (ACH) and debit cards for instant cash-out, issues Venmo Mastercard Debit & Visa Credit cards, and supports buying/sending crypto.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Primarily enforces SMS 6-digit code to registered phone number; email verification used for identity recovery.',
      loginVerificationGuide:
        '1. Enter email, phone, or username and password. 2. Venmo sends a 6-digit SMS code to your registered mobile phone (and may ask you to confirm your linked bank/card digits).',
    },
  },
  'cash.app': {
    category: 'Banking & Financial Services',
    siteSubType: 'P2P Payment Wallet, Banking & Bitcoin App',
    description:
      'Block (Square) mobile finance app for instant peer-to-peer money transfers ($Cashtag), Cash Card debit spending, direct deposits, stock investing, and Bitcoin wallet transfers.',
    tags: ['P2P Payments', 'Bitcoin Wallet', 'Mobile Banking'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Cash App Offers provide instant % discounts and Bitcoin boosts on Cash Card debit purchases.',
      hasGiftCards: true,
      giftCardDetails: 'Allows sending retail brand gift cards directly to friends inside the app.',
      isBankOrFinancial: true,
      financialSubType: 'P2P Payment Wallet, Mobile Banking & Bitcoin On-Ramp',
      financialDetails:
        'Hybrid P2P wallet, neobank & Bitcoin wallet: Holds USD balance with routing/account numbers, issues Visa Cash Card, trades fractional stocks, and allows buying, selling, and withdrawing Bitcoin on-chain or via Lightning Network.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Passwordless login using a one-time verification code sent to either your registered Phone Number (SMS) or Email address, plus Cash PIN.',
      loginVerificationGuide:
        '1. Enter your registered phone number or email address. 2. Enter the 6-digit one-time login code received via SMS or Email. 3. Enter your 4-digit Cash PIN to confirm.',
    },
  },
  'wise.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Multi-Currency Account & International Wire Platform',
    description:
      'International money transfer and multi-currency borderless account platform for holding, exchanging, and wiring 40+ currencies at real mid-market FX rates.',
    tags: ['International Transfers', 'Multi-Currency Bank', 'FX'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'Provides high-yield interest on USD/EUR/GBP balances rather than points.',
      hasGiftCards: false,
      giftCardDetails: 'No gift cards.',
      isBankOrFinancial: true,
      financialSubType: 'International Remittance & Multi-Currency Account',
      financialDetails:
        'Cross-border banking & FX platform: Provides local bank account details (US routing, UK sort code, Euro IBAN) to receive/send international wires, ACH, SEPA, and Swift transfers, plus a multi-currency Visa/Mastercard debit card.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports Wise App push approval, SMS/voice OTP codes, WhatsApp codes, and Passkeys.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Approve login notification in the Wise mobile app, or click "Confirm another way" to receive an SMS or voice code.',
    },
  },
  'revolut.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Global Neobank, Multi-Currency & Crypto App',
    description:
      'Global financial super-app and neobank offering multi-currency bank accounts, virtual disposable debit cards, international transfers, stock trading, and crypto exchange.',
    tags: ['Neobank', 'Multi-Currency', 'Crypto & Stocks'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'RevPoints earned on card spending, redeemable for airline miles, hotel stays, and shopping discounts.',
      hasGiftCards: true,
      giftCardDetails: 'In-app gift card marketplace for retail and dining brands.',
      isBankOrFinancial: true,
      financialSubType: 'Global Neobank, FX Wallet & Crypto/Stock App',
      financialDetails:
        'All-in-one neobank: Offers checking & savings vaults, disposable virtual cards for secure online shopping, instant P2P transfers, international FX wires, and in-app stock & cryptocurrency buying.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Requires phone number + passcode, reinforced with SMS OTP, selfie biometrics, or email confirmation.',
      loginVerificationGuide:
        '1. Enter registered mobile phone number and passcode. 2. Approve via mobile app push prompt or enter 6-digit SMS/email verification code.',
    },
  },
  'klarna.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Buy Now, Pay Later (BNPL) & Shopping Financing',
    description:
      'Buy Now, Pay Later (BNPL) consumer financing platform allowing shoppers to split online purchases into 4 interest-free installments or monthly financing.',
    tags: ['BNPL', 'Consumer Financing', 'Shopping'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Klarna cashback earned when shopping through the Klarna app, withdrawable to bank accounts.',
      hasGiftCards: true,
      giftCardDetails: 'Allows buying retail gift cards using Pay in 4 installments.',
      isBankOrFinancial: true,
      financialSubType: 'Buy Now, Pay Later (BNPL) & Consumer Credit',
      financialDetails:
        'Point-of-sale consumer lender: Issues one-time virtual Visa cards and installment plans linked to a user’s debit card or bank account.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Passwordless login using SMS verification code to phone alongside email confirmation.',
      loginVerificationGuide:
        '1. Enter phone number or email. 2. Enter 6-digit verification code sent via SMS or email link.',
    },
  },
  'affirm.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'Buy Now, Pay Later (BNPL) & Consumer Lending',
    description:
      'Point-of-sale consumer lending network offering Pay in 4 and monthly installment loans for online and in-store retail purchases, plus Affirm Money high-yield savings.',
    tags: ['BNPL', 'Installment Loans', 'FinTech'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'Focuses on transparent installment financing and high-yield savings rather than points.',
      hasGiftCards: false,
      giftCardDetails: 'Virtual card can be used at eligible merchants.',
      isBankOrFinancial: true,
      financialSubType: 'Buy Now, Pay Later (BNPL) & High-Yield Savings',
      financialDetails:
        'Consumer credit & savings platform: Provides instant installment loans, physical/virtual Affirm Debit+ cards, and FDIC-insured high-yield savings accounts.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Uses mobile phone SMS 6-digit PIN as primary sign-in factor, with email recovery verification.',
      loginVerificationGuide:
        '1. Enter registered mobile number. 2. Enter the 6-digit SMS verification code sent to your phone.',
    },
  },
  'stripe.com': {
    category: 'Banking & Financial Services',
    siteSubType: 'B2B Payment Gateway & Financial Infrastructure',
    description:
      'Merchant payment processing platform and financial API infrastructure for accepting credit cards, managing subscriptions, issuing payouts, and corporate banking.',
    tags: ['Payment Processor', 'Merchant Payouts', 'FinTech API'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'B2B merchant financial infrastructure without consumer loyalty points.',
      hasGiftCards: false,
      giftCardDetails: 'Supports merchant issuing of gift cards via API.',
      isBankOrFinancial: true,
      financialSubType: 'Merchant Payment Processor & Payout Treasury',
      financialDetails:
        'Business payment processor & treasury platform: Collects customer card/wallet payments, holds merchant settlement balances, processes refunds, and disburses payouts to linked business bank accounts.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Supports SMS phone number verification, TOTP authenticator apps, WebAuthn hardware keys, and backup email recovery codes.',
      loginVerificationGuide:
        '1. Enter email & password. 2. Authenticate via default method (Authenticator app or Phone SMS). 3. If phone/app unavailable, click "Use another verification method" to receive a fallback code to your primary email address.',
    },
  },

  // E-Commerce & Retail
  'amazon.com': {
    category: 'E-Commerce & Retail',
    siteSubType: 'Global Online Retail Marketplace & Cloud',
    description:
      'Global e-commerce marketplace for retail shopping, electronics, groceries, digital streaming (Prime), and stored Amazon Pay / Gift Card wallet balances.',
    tags: ['Retail Marketplace', 'E-Commerce', 'Gift Cards'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Amazon Prime Visa yields 5% back in points, redeemable at checkout or as cash statement credit.',
      hasGiftCards: true,
      giftCardDetails: 'Extensive store of Amazon physical/e-gift cards and third-party retailer/Visa gift cards.',
      isBankOrFinancial: false,
      financialSubType: 'Stored Value Gift Card Balance & Amazon Pay Wallet',
      financialDetails:
        'Retail marketplace with stored-value wallet: Holds non-expiring Amazon Gift Card balance, stored credit/debit cards, and Shop with Points integrations.',
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Two-Step Verification supports Phone SMS codes, Authenticator apps, and email OTP/approval links for new devices.',
      loginVerificationGuide:
        '1. Enter email/phone and password. 2. Amazon sends OTP to phone number via SMS or authenticator app. 3. If unrecognized device, an email approval link ("Approve or Deny") or OTP is also dispatched.',
    },
  },
  'starbucks.com': {
    category: 'E-Commerce & Retail',
    siteSubType: 'Food & Beverage Chain & Stored-Value App',
    description:
      'Specialty coffee retailer offering mobile order-ahead, reloadable Starbucks Card balances, and Starbucks Rewards loyalty Stars.',
    tags: ['Coffee & Dining', 'Stored Balance', 'Loyalty Rewards'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Starbucks Rewards lets members earn Stars per dollar spent to redeem for free beverages, food, and merchandise.',
      hasGiftCards: true,
      giftCardDetails: 'Sells digital and physical gift cards, reloadable in the mobile app.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Supports SMS verification to mobile number and Email one-time passcode links for account sign-in.',
      loginVerificationGuide:
        '1. Enter registered email address. 2. Starbucks offers sign-in via password or Email one-time sign-in link, plus SMS verification on mobile number.',
    },
  },
  'target.com': {
    category: 'E-Commerce & Retail',
    siteSubType: 'Department Store & E-Commerce Retailer',
    description:
      'National department store and online retailer offering groceries, electronics, apparel, gift cards, and Target Circle loyalty rewards.',
    tags: ['Retail', 'Department Store', 'Shopping'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Target Circle allows earning reward funds to apply at checkout, plus 5% off with Circle Card.',
      hasGiftCards: true,
      giftCardDetails: 'Sells Target gift cards and third-party gift cards (Apple, Disney, Visa) both in-store and online.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports Phone SMS codes and Email passcodes for sign-in verification.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Select verification channel: "Text code to mobile" or "Send code to email". 3. Enter 6-digit code to log in.',
    },
  },
  'walmart.com': {
    category: 'E-Commerce & Retail',
    siteSubType: 'Superstore & Online Grocery Marketplace',
    description:
      'Mass-market retail superstore with online shopping, same-day grocery delivery, Walmart Pay wallet, and Walmart+ membership rewards.',
    tags: ['Retail', 'Groceries', 'E-Commerce'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Walmart Cash earned through Walmart+ membership or manufacturer offers, applied to future purchases or cashed out at MoneyCenter.',
      hasGiftCards: true,
      giftCardDetails: 'Sells electronic and physical gift cards for Walmart and partner brands.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Supports Phone SMS OTP codes and single-use verification codes sent to email.',
      loginVerificationGuide:
        '1. Enter email. 2. Walmart prompts for password or provides option to "Send a code to phone" or "Send a code to email". 3. Submit code to verify account.',
    },
  },
  'swagbucks.com': {
    category: 'Rewards & Earning Platforms',
    siteSubType: 'Cashback & Paid Survey Rewards Portal',
    description:
      'Online rewards and cashback portal where users earn SB points for shopping online, answering surveys, and testing apps, redeemable for PayPal cash or gift cards.',
    tags: ['Rewards Portal', 'Cashback', 'Gift Cards'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Users earn SB points that can be withdrawn as PayPal cash deposits or redeemed for retail gift cards.',
      hasGiftCards: true,
      giftCardDetails: 'Primary redemption mechanism is digital gift cards (Amazon, Walmart, Visa prepaid, Apple).',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Requires email confirmation codes for sign-in/password changes and phone number SMS OTP verification for gift card and cash redemptions.',
      loginVerificationGuide:
        '1. Enter email and password. 2. For unrecognized logins or password reset, verification link is sent to email. 3. When redeeming gift cards or withdrawing funds, SMS code verification to a mobile phone is strictly required.',
    },
  },

  // Travel & Airlines
  'aa.com': {
    category: 'Travel & Airlines',
    siteSubType: 'Commercial Airline & Frequent Flyer Portal',
    description:
      'American Airlines reservation portal for booking domestic/international flights, managing travel credits, and redeeming AAdvantage frequent flyer miles.',
    tags: ['Airline', 'Travel Booking', 'Frequent Flyer Miles'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'AAdvantage loyalty miles can be earned on flights and partner credit cards, redeemable for award flights, cabin upgrades, hotels, and car rentals.',
      hasGiftCards: true,
      giftCardDetails: 'American Airlines sells physical and virtual flight gift cards.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'AAdvantage account verification supports both SMS text code to phone and security code sent to email.',
      loginVerificationGuide:
        '1. Enter AAdvantage # and password. 2. If device challenge appears, choose "Text me a code" or "Email me a code". 3. Enter 6-digit code to log in.',
    },
  },
  'delta.com': {
    category: 'Travel & Airlines',
    siteSubType: 'Commercial Airline & Frequent Flyer Portal',
    description:
      'Delta Air Lines official portal for flight bookings, eCredit management, and SkyMiles frequent flyer mileage redemptions.',
    tags: ['Airline', 'Travel Booking', 'SkyMiles'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Delta SkyMiles earned on flights and Amex transfers, redeemable for award travel, seat upgrades, or Delta vacation packages.',
      hasGiftCards: true,
      giftCardDetails: 'Sells Delta Air Lines eGift and physical cards.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Delta Two-Step Verification supports both SMS text message to mobile phone and security code sent to email.',
      loginVerificationGuide:
        '1. Enter SkyMiles number or username and password. 2. Select verification destination (Mobile SMS or Email address). 3. Enter security code to verify device.',
    },
  },
  'united.com': {
    category: 'Travel & Airlines',
    siteSubType: 'Commercial Airline & Frequent Flyer Portal',
    description:
      'United Airlines flight reservation system, travel bank credit wallet, and MileagePlus frequent flyer loyalty program.',
    tags: ['Airline', 'Travel Booking', 'MileagePlus'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'MileagePlus miles earned and redeemable for flights, hotel stays, and gift cards via MileagePlus X.',
      hasGiftCards: true,
      giftCardDetails: 'MileagePlus X app allows buying merchant gift cards with miles or cash.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'United MileagePlus supports both phone number SMS verification and email passcode verification for account access.',
      loginVerificationGuide:
        '1. Enter MileagePlus number and password. 2. Choose whether to receive security code via SMS or email. 3. Enter 6-digit code to complete login.',
    },
  },
  'booking.com': {
    category: 'Travel & Airlines',
    siteSubType: 'Online Travel Agency (Hotels & Flights)',
    description:
      'Global online travel agency (OTA) for booking hotels, vacation rentals, flights, and car rentals with Booking Wallet travel credits.',
    tags: ['Hotels & Lodging', 'Travel Agency', 'Reservations'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails: 'Genius loyalty program provides tier-based discounts, Wallet travel credits, free breakfast, and room upgrades.',
      hasGiftCards: true,
      giftCardDetails: 'Offers Booking.com gift cards redeemable for hotel accommodations.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails: 'Offers email verification magic links and phone number SMS OTP verification codes.',
      loginVerificationGuide:
        '1. Enter email address. 2. Choose sign-in with password + SMS OTP, or passwordless one-time verification link sent to email.',
    },
  },

  // Tech Infrastructure & Developer Tools
  'github.com': {
    category: 'Tech Infrastructure & Developer Tools',
    siteSubType: 'Source Code Hosting & DevOps Platform',
    description:
      'Software development platform for hosting Git code repositories, running CI/CD pipelines (GitHub Actions), and managing open-source or enterprise codebases.',
    tags: ['Developer Tools', 'Git Repositories', 'CI/CD'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'Developer platform without points or cashback rewards.',
      hasGiftCards: false,
      giftCardDetails: 'No gift cards.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'No',
      twoFactorType: 'Phone Only',
      twoFactorDetails:
        'Mandatory 2FA supports Authenticator apps (TOTP), SMS phone numbers, and FIDO2 security keys. Note: GitHub does NOT allow email as a primary 2FA method.',
      loginVerificationGuide:
        '1. Enter username and password. 2. GitHub requests 2FA code. 3. Enter 6-digit TOTP from your authenticator app or receive SMS to your phone number. 4. If using security keys (YubiKey/Touch ID), tap the key. 5. Email cannot be used as a 2FA login factor.',
    },
  },
  'vercel.com': {
    category: 'Tech Infrastructure & Developer Tools',
    siteSubType: 'Cloud Web Hosting & Serverless Platform',
    description:
      'Frontend cloud platform for deploying and hosting Next.js, React, and serverless web applications with global edge CDN.',
    tags: ['Cloud Hosting', 'Frontend', 'Serverless'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'Developer cloud platform without consumer points.',
      hasGiftCards: false,
      giftCardDetails: 'No gift cards.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Supports TOTP authenticator apps, SMS phone numbers, and Email login verification links (Magic Links).',
      loginVerificationGuide:
        '1. Enter email. 2. Choose password + 2FA (TOTP/SMS) or click "Continue with Email" to receive an instant verification link in your inbox.',
    },
  },
  'cloudflare.com': {
    category: 'Tech Infrastructure & Developer Tools',
    siteSubType: 'DNS, CDN & Web Security Infrastructure',
    description:
      'Web infrastructure and cybersecurity platform providing domain DNS management, domain registration, DDoS protection, and edge CDN services.',
    tags: ['Cybersecurity', 'CDN & DNS', 'Domain Registrar'],
    rewards: {
      hasRewardsOrPoints: false,
      canEarn: false,
      canWithdrawOrRedeem: false,
      rewardsDetails: 'Infrastructure service without consumer points.',
      hasGiftCards: false,
      giftCardDetails: 'No gift cards.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Cloudflare supports TOTP authenticator apps, hardware security keys, SMS codes, and email verification for new IP logins.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Enter 6-digit code from authenticator app or SMS. 3. If accessing from unrecognized location without 2FA, an email authorization token is sent.',
    },
  },
  'google.com': {
    category: 'Search & Productivity',
    siteSubType: 'Search Engine, Email (Gmail) & Cloud Ecosystem',
    description:
      'Core Google account ecosystem providing Gmail, Google Drive cloud storage, Google Pay wallet, YouTube, and Google Play digital store.',
    tags: ['Search & Email', 'Cloud Ecosystem', 'Google Pay'],
    rewards: {
      hasRewardsOrPoints: true,
      canEarn: true,
      canWithdrawOrRedeem: true,
      rewardsDetails:
        'Google Play Points earned on digital store purchases; Google Opinion Rewards yields Google Play credit or PayPal payouts.',
      hasGiftCards: true,
      giftCardDetails: 'Google Play digital and physical gift cards widely available.',
      isBankOrFinancial: false,
      supportsPhone2FA: 'Yes',
      supportsEmail2FA: 'Yes',
      twoFactorType: 'Both',
      twoFactorDetails:
        'Google 2-Step Verification supports Phone prompts (Android/iOS), SMS codes, Recovery Email verification, and FIDO2 Security Keys.',
      loginVerificationGuide:
        '1. Enter email and password. 2. Primary 2FA challenge prompts phone (tap "Yes" on phone) or SMS code. 3. If phone is unavailable, click "Try another way" to select "Get a verification code sent to your recovery email address". 4. Enter 6-digit code to log in.',
    },
  },
};

export function fallbackCategorizeDomains(
  domains: string[],
  metadataMap?: Record<string, { count: number; label?: string; occurrences: number }>
): FallbackCategory[] {
  const categoryMap = new Map<string, FallbackItem[]>();

  for (const domain of domains) {
    let cleanDomain = domain.toLowerCase().trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    cleanDomain = cleanDomain.replace(/^\.+|\.+$/g, '');
    const known = KNOWN_DOMAINS[cleanDomain];

    let item: FallbackItem;
    let categoryName: string;

    // Check if domain is an IPv4 host address with optional port (e.g. 192.168.217.50:446)
    const isIpAddress = /^(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?$/.test(cleanDomain);

    if (known) {
      categoryName = known.category;
      item = {
        domain: cleanDomain,
        siteSubType: known.siteSubType,
        description: known.description,
        tags: known.tags,
        rewards: {
          hasRewardsOrPoints: known.rewards?.hasRewardsOrPoints ?? false,
          canEarn: known.rewards?.canEarn ?? false,
          canWithdrawOrRedeem: known.rewards?.canWithdrawOrRedeem ?? false,
          rewardsDetails: known.rewards?.rewardsDetails || 'No loyalty or points program detected.',
          hasGiftCards: known.rewards?.hasGiftCards ?? false,
          giftCardDetails: known.rewards?.giftCardDetails || 'No gift cards available.',
          isBankOrFinancial: known.rewards?.isBankOrFinancial ?? false,
          financialSubType: known.rewards?.financialSubType,
          financialDetails: known.rewards?.financialDetails,
          supportsPhone2FA: known.rewards?.supportsPhone2FA || 'Yes',
          supportsEmail2FA: known.rewards?.supportsEmail2FA || 'Yes',
          twoFactorType: known.rewards?.twoFactorType || 'Both',
          twoFactorDetails: known.rewards?.twoFactorDetails || '',
          loginVerificationGuide:
            known.rewards?.loginVerificationGuide ||
            'Enter credentials, followed by 2FA verification code sent via phone SMS or email.',
        },
      };
    } else if (isIpAddress) {
      categoryName = 'Tech Infrastructure & Network Hosts';
      const portMatch = cleanDomain.match(/:(\d+)$/);
      const portInfo = portMatch ? ` on port ${portMatch[1]}` : '';
      item = {
        domain: cleanDomain,
        siteSubType: 'IPv4 Server / Network Endpoint',
        description: `Direct IPv4 server or private network host endpoint (${cleanDomain})${portInfo} used for remote server administration, RDP/SSH access, VPN routing, or internal web services.`,
        tags: ['Network Host', 'Server Endpoint', 'IPv4 Address'],
        rewards: {
          hasRewardsOrPoints: false,
          canEarn: false,
          canWithdrawOrRedeem: false,
          rewardsDetails: 'Direct server and network host without consumer rewards.',
          hasGiftCards: false,
          giftCardDetails: 'No gift cards.',
          isBankOrFinancial: false,
          supportsPhone2FA: 'N/A',
          supportsEmail2FA: 'N/A',
          twoFactorType: 'N/A',
          twoFactorDetails: 'Direct authentication via SSH key, RDP credentials, VPN gateway, or admin console.',
          loginVerificationGuide:
            '1. Connect via VPN or direct network route. 2. Authenticate using SSH key, RDP credentials, or web admin login.',
        },
      };
    } else {
      // Granular heuristic detection for financial sub-types & general categories
      const isCryptoWalletOrDeFi =
        /metamask|phantom|trustwallet|ledger|trezor|exodus|rabby|uniswap|pancake|aave|curve|1inch|defi|web3|dapp|nft|opensea|etherscan|solscan/i.test(
          cleanDomain
        );
      const isCryptoExchange =
        /crypto|coin|bitcoin|btc|eth|binance|kraken|kucoin|bybit|okx|bitget|gemini|bitstamp|gate\.io|huobi|mexc|uphold|bitfinex|paxful|moonpay|simplex|banxa|token|blockchain|swap|dex/i.test(
          cleanDomain
        );
      const isInvestmentOrBrokerage =
        /invest|trade|trading|broker|stock|stocks|wealth|fidelity|vanguard|schwab|robinhood|etrade|webull|merrill|acorns|stash|betterment|wealthfront|interactivebrokers|ibkr|tdameritrade|tastytrade|questrade|allyinvest|ira|401k|portfolio|asset|fund|forex|fx|etoro|plus500/i.test(
          cleanDomain
        );
      const isP2POrPaymentWallet =
        /paypal|venmo|cash\.app|cashapp|zelle|wise|transferwise|revolut|remit|remitly|westernunion|moneygram|payoneer|skrill|neteller|alipay|wechatpay|applepay|googlepay|gpay|klarna|affirm|afterpay|sezzle|zip\.co|pay\b|wallet|payment/i.test(
          cleanDomain
        );
      const isCreditUnion = /fcu|cu\.org|creditunion|navyfederal|penfed|alliant|becu|schoolsfirst/i.test(
        cleanDomain
      );
      const isRetailBankOrCard =
        /bank|banking|chase|wellsfargo|citi|bofa|capitalone|amex|americanexpress|discover|usbank|pnc|truist|td\.com|tdbank|regions|fifth|huntington|keybank|citizensbank|santander|hsbc|barclays|lloyds|natwest|rbc|tdcanadatrust|scotiabank|bmo|cibc|ally\.com|chime|sofi|synchrony|breadfinancial|comenity|mortgage|loan|lending|credit|card|finance|financial|trust/i.test(
          cleanDomain
        );

      const isTravel = /travel|air|airline|flight|fly|hotel|marriott|hilton|hyatt|ihg|wyndham|airbnb|vrbo|expedia|priceline|kayak|orbitz|agoda|tour|trip|inn|resort|cruise|carnival|royalcaribbean|amtrak|uber|lyft|hertz|avis|enterprise/i.test(
        cleanDomain
      );
      const isEcommerce = /shop|store|market|buy|deal|mall|retail|outlet|cart|ebay|etsy|shopify|bestbuy|costco|samsclub|macys|nordstrom|nike|adidas|homedepot|lowes|wayfair|shein|temu|aliexpress|newegg|doordash|instacart|ubereats|grubhub/i.test(
        cleanDomain
      );
      const isRewards = /reward|point|cashback|miles|survey|bonus|perk|swag|earn|rakuten|ibotta|fetch|honey|inboxdollars|freecash/i.test(
        cleanDomain
      );
      const isTech = /git|cloud|aws|azure|gcp|dev|api|code|host|server|stack|app|io\b|tech|digitalocean|linode|heroku|netlify|render|supabase|firebase|mongodb|docker|openai|anthropic|slack|notion|zoom|figma|canva|adobe|microsoft|apple|icloud/i.test(
        cleanDomain
      );
      const isSocialOrMedia = /social|chat|media|video|stream|music|game|gaming|play|netflix|spotify|hulu|disney|twitch|youtube|tiktok|instagram|facebook|meta|twitter|x\.com|reddit|discord|telegram|whatsapp|linkedin|Snapchat|pinterest|steam|epicgames|playstation|xbox|nintendo/i.test(
        cleanDomain
      );

      if (isCryptoWalletOrDeFi) {
        categoryName = 'Crypto Wallets, Exchanges & Web3';
        item = {
          domain: cleanDomain,
          siteSubType: 'Crypto Wallet / DeFi & Web3 Platform',
          description: `Cryptocurrency wallet and Web3 decentralized finance (DeFi) platform at ${cleanDomain} for storing digital tokens, managing private keys, and interacting with blockchain dApps.`,
          tags: ['Crypto Wallet', 'DeFi & Web3', 'Self-Custody'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Often supports on-chain token staking, DeFi liquidity yield, or airdrop points.',
            hasGiftCards: false,
            giftCardDetails: 'Blockchain wallet without traditional retail gift cards.',
            isBankOrFinancial: true,
            financialSubType: 'Crypto Wallet / Web3 & DeFi Platform',
            financialDetails: `Cryptocurrency & Web3 platform (${cleanDomain}): Used for holding digital currencies (BTC, ETH, SOL, stablecoins), swapping tokens on decentralized exchanges, staking assets, and sending/receiving on-chain crypto transfers.`,
            supportsPhone2FA: 'Optional',
            supportsEmail2FA: 'Optional',
            twoFactorType: 'App/Security Key',
            twoFactorDetails:
              'Typically secured via 12/24-word Secret Recovery Phrase, local wallet password, hardware wallet signature, or authenticator app.',
            loginVerificationGuide:
              '1. Unlock wallet using local password/PIN or connect hardware key. 2. For hosted accounts, verify via Authenticator app or email confirmation.',
          },
        };
      } else if (isCryptoExchange) {
        categoryName = 'Crypto Wallets, Exchanges & Web3';
        item = {
          domain: cleanDomain,
          siteSubType: 'Cryptocurrency Exchange & Custodial Wallet',
          description: `Cryptocurrency exchange and digital asset platform at ${cleanDomain} for buying, selling, trading, and holding Bitcoin, Ethereum, stablecoins, and altcoins.`,
          tags: ['Crypto Exchange', 'Crypto Wallet', 'Digital Assets'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Supports crypto staking yields, trading fee rebates, and earn programs withdrawable to crypto wallets.',
            hasGiftCards: false,
            giftCardDetails: 'Primarily handles crypto and fiat conversions.',
            isBankOrFinancial: true,
            financialSubType: 'Cryptocurrency Exchange & Custodial Wallet',
            financialDetails: `Cryptocurrency exchange & wallet (${cleanDomain}): Allows users to deposit fiat currency (via bank ACH/wire or card), trade cryptocurrencies (spot/margin), hold custodial crypto balances, and withdraw coins to external blockchain wallets.`,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails:
              'Enforces strict 2FA combining Authenticator App (TOTP) or Phone SMS codes with mandatory Email confirmation codes for logins and crypto withdrawals.',
            loginVerificationGuide:
              '1. Enter email and password. 2. Input 6-digit code from Authenticator app or SMS. 3. Confirm new device/IP or withdrawal request via the verification code sent to your email.',
          },
        };
      } else if (isInvestmentOrBrokerage) {
        categoryName = 'Banking & Financial Services';
        item = {
          domain: cleanDomain,
          siteSubType: 'Investment Brokerage & Wealth Management',
          description: `Investment brokerage and wealth management platform at ${cleanDomain} for trading stocks, ETFs, options, mutual funds, or managing retirement portfolios.`,
          tags: ['Investment Brokerage', 'Stocks & ETFs', 'Wealth Management'],
          rewards: {
            hasRewardsOrPoints: false,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Earns investment dividends, interest yield on uninvested cash sweep, or deposit match bonuses.',
            hasGiftCards: false,
            giftCardDetails: 'Investment custodian without retail gift cards.',
            isBankOrFinancial: true,
            financialSubType: 'Stock & Investment Brokerage / Wealth Management',
            financialDetails: `Investment & brokerage platform (${cleanDomain}): Holds taxable trading portfolios, retirement accounts (IRA/401k), stocks, ETFs, options, and cash sweep balances with ACH/wire bank transfers for deposits and cash withdrawals.`,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails:
              'Supports Phone SMS/voice OTP codes, Authenticator apps, and email security challenges for unrecognized logins.',
            loginVerificationGuide:
              '1. Enter username/email and password. 2. Complete 2FA challenge via SMS text code to registered phone number, authenticator app, or email code.',
          },
        };
      } else if (isP2POrPaymentWallet) {
        categoryName = 'Banking & Financial Services';
        item = {
          domain: cleanDomain,
          siteSubType: 'Digital Payment Wallet & P2P Money Transfer',
          description: `Digital payment wallet, peer-to-peer (P2P) money transfer, or consumer payment financing platform at ${cleanDomain}.`,
          tags: ['Digital Wallet', 'P2P Payments', 'Money Transfer'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Often provides cashback offers or payment rewards redeemable to wallet balance.',
            hasGiftCards: true,
            giftCardDetails: 'Many digital wallets support sending digital gift cards or prepaid balances.',
            isBankOrFinancial: true,
            financialSubType: 'Digital Wallet, P2P Money Transfer & Payment App',
            financialDetails: `Digital wallet & payments app (${cleanDomain}): Stores spendable cash balances or linked bank/card payment methods to send peer-to-peer transfers, pay online merchants, remit money internationally, or cash out instantly to a debit card or bank account.`,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails:
              'Supports SMS one-time passcodes to mobile phone numbers and email verification codes/magic links.',
            loginVerificationGuide:
              '1. Enter email or mobile phone number and password. 2. Verify identity using the 6-digit SMS code sent to your phone or verification link sent to email.',
          },
        };
      } else if (isCreditUnion) {
        categoryName = 'Banking & Financial Services';
        item = {
          domain: cleanDomain,
          siteSubType: 'Member Credit Union (Banking & Loans)',
          description: `Member-owned credit union banking portal at ${cleanDomain} offering checking, share savings, auto/home loans, and credit cards.`,
          tags: ['Credit Union', 'Checking & Savings', 'Loans'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Credit union member rewards and credit card points redeemable for cash deposit or statement credit.',
            hasGiftCards: true,
            giftCardDetails: 'Points often redeemable for merchant and Visa gift cards.',
            isBankOrFinancial: true,
            financialSubType: 'Credit Union (Consumer Banking & Lending)',
            financialDetails: `NCUA-insured credit union (${cleanDomain}): Holds member checking and share savings accounts, certificates of deposit, auto/mortgage loans, credit cards, ACH transfers, and Zelle/bill pay.`,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails: 'Supports both Phone SMS/voice call verification codes and Email security passcodes.',
            loginVerificationGuide:
              '1. Enter Member Username and password. 2. Select SMS text, voice call, or Email to receive a 6-digit verification code.',
          },
        };
      } else if (isRetailBankOrCard) {
        categoryName = 'Banking & Financial Services';
        item = {
          domain: cleanDomain,
          siteSubType: 'Retail Bank & Credit Card / Lending Portal',
          description: `Retail bank, credit card issuer, or lending institution at ${cleanDomain} providing online account management, deposits, and payments.`,
          tags: ['Retail Bank', 'Credit & Lending', 'Online Banking'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Offers card cashback or banking points redeemable for statement credit, direct deposit, or travel.',
            hasGiftCards: true,
            giftCardDetails: 'Rewards points can typically be redeemed for retail gift cards.',
            isBankOrFinancial: true,
            financialSubType: 'Retail Bank / Credit Card & Lending Institution',
            financialDetails: `Financial banking & credit platform (${cleanDomain}): Manages checking/savings cash deposits, credit cards or loan balances, ACH bank-to-bank transfers, wire transfers, and bill payments.`,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails:
              'Supports both Phone SMS/Voice verification codes and Email one-time security codes for login and transaction authorization.',
            loginVerificationGuide:
              '1. Enter User ID and password. 2. System prompts for two-factor verification. 3. Choose between receiving an OTP code on your registered mobile number (SMS/voice call) or your verified email address. 4. Submit the 6-digit code to complete login.',
          },
        };
      } else if (isRewards) {
        categoryName = 'Rewards & Loyalty Programs';
        item = {
          domain: cleanDomain,
          siteSubType: 'Cashback, Survey & Loyalty Rewards Portal',
          description: `Rewards, cashback, or loyalty points platform at ${cleanDomain} where users earn rebates or points and cash out via PayPal, bank transfer, or gift cards.`,
          tags: ['Rewards', 'Loyalty', 'Cashback'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Offers point or cashback earning mechanisms with PayPal/bank cash-out and gift card redemption options.',
            hasGiftCards: true,
            giftCardDetails: 'Points or rewards can be redeemed for digital gift cards (Amazon, Visa, Walmart, Target).',
            isBankOrFinancial: false,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails:
              'Uses email verification for account access and phone number SMS OTP verification for cash withdrawals and gift card redemptions.',
            loginVerificationGuide:
              '1. Sign in with email and password. 2. Email verification code sent for unrecognized devices. 3. Phone number SMS verification required when withdrawing cash or gift cards.',
          },
        };
      } else if (isTravel) {
        categoryName = 'Travel & Hospitality';
        item = {
          domain: cleanDomain,
          siteSubType: 'Airline, Hotel & Travel Booking Platform',
          description: `Travel reservation, airline ticketing, hotel lodging, or ride-hailing platform at ${cleanDomain} with loyalty points/miles and stored travel credits.`,
          tags: ['Travel', 'Bookings', 'Loyalty Miles'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Frequent traveler miles or hotel loyalty points earned on bookings, redeemable for free stays, flights, or upgrades.',
            hasGiftCards: true,
            giftCardDetails: 'Travel gift cards or vouchers available for purchase or point redemption.',
            isBankOrFinancial: false,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails: 'Supports SMS mobile verification and email security codes for reservation and loyalty management.',
            loginVerificationGuide:
              '1. Enter member number/email and password. 2. Select SMS code or Email code delivery. 3. Enter 6-digit code to access travel profile.',
          },
        };
      } else if (isEcommerce) {
        categoryName = 'E-Commerce & Retail';
        item = {
          domain: cleanDomain,
          siteSubType: 'Online Retail Store & Shopping Marketplace',
          description: `Online retail store, shopping marketplace, or delivery service at ${cleanDomain} for purchasing consumer goods, managing orders, and using stored payment/gift card balances.`,
          tags: ['Retail', 'E-Commerce', 'Shopping'],
          rewards: {
            hasRewardsOrPoints: true,
            canEarn: true,
            canWithdrawOrRedeem: true,
            rewardsDetails: 'Provides store loyalty points, member cashback, or checkout discounts.',
            hasGiftCards: true,
            giftCardDetails: 'Sells digital and physical store gift cards redeemable at checkout.',
            isBankOrFinancial: false,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails: 'Supports Phone SMS verification codes and Email one-time passcodes for sign-in.',
            loginVerificationGuide:
              '1. Enter email and password. 2. Choose OTP via SMS or Email. 3. Enter code to access orders and saved payment methods.',
          },
        };
      } else if (isSocialOrMedia) {
        categoryName = 'Social Media, Streaming & Gaming';
        item = {
          domain: cleanDomain,
          siteSubType: 'Social Network, Digital Streaming or Gaming Platform',
          description: `Digital entertainment, social networking, streaming subscription, or gaming platform at ${cleanDomain}.`,
          tags: ['Entertainment', 'Social / Streaming', 'Digital Account'],
          rewards: {
            hasRewardsOrPoints: false,
            canEarn: false,
            canWithdrawOrRedeem: false,
            rewardsDetails: 'May include in-app creator balances, virtual coins, or gaming store wallet credits.',
            hasGiftCards: true,
            giftCardDetails: 'Often supports subscription or gaming wallet gift cards.',
            isBankOrFinancial: false,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails: 'Supports SMS phone verification codes, Email login codes, and Authenticator apps.',
            loginVerificationGuide:
              '1. Enter username/email and password. 2. Enter 6-digit security code sent via SMS, Email, or Authenticator app.',
          },
        };
      } else if (isTech) {
        categoryName = 'Tech Infrastructure & Developer Tools';
        item = {
          domain: cleanDomain,
          siteSubType: 'Cloud SaaS, Developer Platform or Web Infrastructure',
          description: `Cloud computing, software-as-a-service (SaaS), developer tooling, or web infrastructure platform at ${cleanDomain}.`,
          tags: ['Tech & Cloud', 'SaaS', 'Developer Tools'],
          rewards: {
            hasRewardsOrPoints: false,
            canEarn: false,
            canWithdrawOrRedeem: false,
            rewardsDetails: 'Cloud/SaaS service (may hold prepaid billing credits rather than consumer loyalty points).',
            hasGiftCards: false,
            giftCardDetails: 'No consumer gift cards.',
            isBankOrFinancial: false,
            supportsPhone2FA: 'Yes',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails: 'Supports TOTP authenticator apps, SMS phone numbers, and email authorization tokens.',
            loginVerificationGuide:
              '1. Enter credentials. 2. Prompt requests TOTP authenticator or phone SMS code. 3. Fallback email verification available if device is unrecognized.',
          },
        };
      } else {
        categoryName = 'General Web Services & Online Portals';
        item = {
          domain: cleanDomain,
          siteSubType: 'Online Web Service & Account Portal',
          description: `Online service portal and web platform (${cleanDomain}) providing user account management and digital services.`,
          tags: ['Web Service', 'Account Portal'],
          rewards: {
            hasRewardsOrPoints: false,
            canEarn: false,
            canWithdrawOrRedeem: false,
            rewardsDetails: 'No standard consumer loyalty rewards program detected.',
            hasGiftCards: false,
            giftCardDetails: 'No gift cards detected.',
            isBankOrFinancial: false,
            supportsPhone2FA: 'Optional',
            supportsEmail2FA: 'Yes',
            twoFactorType: 'Both',
            twoFactorDetails: 'Standard account verification via Email one-time code or optional SMS phone verification.',
            loginVerificationGuide:
              '1. Enter email/username and password. 2. If prompted for verification, enter the security code sent to your email or mobile phone.',
          },
        };
      }
    }

    if (metadataMap && metadataMap[cleanDomain]) {
      const meta = metadataMap[cleanDomain];
      item.pastedCount = meta.count;
      item.pastedLabel = meta.label;
      item.rawOccurrences = meta.occurrences;
    }

    if (!categoryMap.has(categoryName)) {
      categoryMap.set(categoryName, []);
    }
    categoryMap.get(categoryName)!.push(item);
  }

  const result: FallbackCategory[] = [];
  for (const [name, items] of categoryMap.entries()) {
    result.push({
      name,
      description: `Collection of ${items.length} ${items.length === 1 ? 'site' : 'sites'} in ${name}.`,
      items,
    });
  }

  return result;
}

export function buildMarkdown(categories: any[], stats?: any): string {
  let md = '# Website & App Categorization Results\n\n';

  if (stats) {
    md += `**Accurate Site Count Summary**:\n`;
    md += `- Pasted Entries: **${stats.pastedLinesCount || 0}**\n`;
    md += `- Total Mentions Detected: **${stats.totalDetectedItems || 0}**\n`;
    md += `- Unique Targets Classified: **${stats.uniqueDomainsCount || 0}**\n`;
    if (stats.duplicateMentionsCount > 0) {
      md += `- Consolidated Repeats/Duplicates: **${stats.duplicateMentionsCount}**\n`;
    }
    if (stats.totalInstancesOrAccounts && stats.totalInstancesOrAccounts > stats.uniqueDomainsCount) {
      md += `- Total Accounts/Items Logged: **${stats.totalInstancesOrAccounts}**\n`;
    }
    md += '\n---\n\n';
  }

  for (const cat of categories) {
    md += `### ${cat.name}\n`;
    if (cat.description) {
      md += `*${cat.description}*\n\n`;
    }
    for (const item of cat.items || []) {
      const r = item.rewards || {};
      const subType = item.siteSubType || r.financialSubType || '';
      const subTypeLabel = subType ? ` **[${subType}]**` : '';
      const tags = item.tags && item.tags.length ? ` \`[${item.tags.join(', ')}]\`` : '';
      const countLabel = item.pastedLabel
        ? ` *(Pasted: ${item.pastedLabel})*`
        : item.pastedCount && item.pastedCount > 1
        ? ` *(Pasted: ${item.pastedCount} accounts/items)*`
        : '';
      md += `- **${item.domain}**${subTypeLabel}${countLabel}: ${item.description}${tags}\n`;

      if (r.isBankOrFinancial || r.financialDetails || r.financialSubType) {
        const finType = r.financialSubType || item.siteSubType || 'Financial Service';
        md += `  - 🏦 **Financial Classification (${finType})**: ${
          r.financialDetails ||
          'Financial institution or money platform supporting account balances, transfers, or asset management.'
        }\n`;
      }

      if (item.rewards) {
        if (r.hasRewardsOrPoints) {
          const earn = r.canEarn ? 'Earn: Yes' : 'Earn: No';
          const withdraw = r.canWithdrawOrRedeem ? 'Withdraw/Redeem: Yes' : 'Withdraw/Redeem: No';
          md += `  - 🎁 **Rewards/Points**: [${earn} | ${withdraw}] ${r.rewardsDetails || ''}\n`;
        }
        if (r.hasGiftCards) {
          md += `  - 💳 **Gift Cards**: ${r.giftCardDetails || 'Sells gift cards or enables points-to-gift-card redemption.'}\n`;
        }
        if (r.twoFactorType && r.twoFactorType !== 'N/A' && r.twoFactorType !== 'None') {
          const typeBadge =
            r.twoFactorType === 'Both'
              ? '🔄 Both (Phone & Email)'
              : r.twoFactorType === 'Phone Only'
              ? '📱 Phone Number Only'
              : r.twoFactorType === 'Email Only'
              ? '✉️ Email Only'
              : r.twoFactorType;
          md += `  - 🔐 **2FA Login Support**: **${typeBadge}** (Phone: ${r.supportsPhone2FA || 'Yes'} | Email: ${r.supportsEmail2FA || 'Yes'})\n`;
          if (r.twoFactorDetails) {
            md += `    - *Verification Channels*: ${r.twoFactorDetails}\n`;
          }
          if (r.loginVerificationGuide) {
            md += `    - 🔑 *How to Log In*: ${r.loginVerificationGuide}\n`;
          }
        } else if (r.isBankOrFinancial) {
          const phone2fa = r.supportsPhone2FA || 'Yes';
          const email2fa = r.supportsEmail2FA || 'Yes';
          md += `  - 🏦 **Bank 2FA Login**: Phone 2FA: **${phone2fa}** | Email 2FA: **${email2fa}**${r.twoFactorDetails ? ` — ${r.twoFactorDetails}` : ''}\n`;
          if (r.loginVerificationGuide) {
            md += `    - 🔑 *How to Log In*: ${r.loginVerificationGuide}\n`;
          }
        }
      }
    }
    md += '\n';
  }
  return md.trim();
}
