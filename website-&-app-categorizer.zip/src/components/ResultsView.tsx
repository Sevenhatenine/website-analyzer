import { useState, useMemo } from 'react';
import { AnalysisResult } from '../types';
import { CategoryCard, FeatureFilterType } from './CategoryCard';
import {
  Search,
  Copy,
  Check,
  Download,
  FileText,
  LayoutGrid,
  List,
  Sparkles,
  Gift,
  CreditCard,
  ShieldCheck,
  Coins,
  RefreshCw,
  Smartphone,
  Mail,
  HelpCircle,
  Lock,
} from 'lucide-react';

interface ResultsViewProps {
  result: AnalysisResult;
  onReanalyze?: () => void;
}

export function ResultsView({ result, onReanalyze }: ResultsViewProps) {
  const [activeTab, setActiveTab] = useState<'cards' | 'table' | 'markdown'>('cards');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [featureFilter, setFeatureFilter] = useState<FeatureFilterType>('all');
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [expandedTableGuides, setExpandedTableGuides] = useState<Record<string, boolean>>({});

  const categories = result.categories || [];

  const toggleTableGuide = (domain: string) => {
    setExpandedTableGuides((prev) => ({ ...prev, [domain]: !prev[domain] }));
  };

  const categoryNames = useMemo(() => {
    return ['all', ...categories.map((c) => c.name)];
  }, [categories]);

  const filteredCategories = useMemo(() => {
    if (selectedCategory === 'all') return categories;
    return categories.filter((c) => c.name === selectedCategory);
  }, [categories, selectedCategory]);

  const totalItemsCount = useMemo(() => {
    return categories.reduce((acc, cat) => acc + (cat.items?.length || 0), 0);
  }, [categories]);

  // Counts for quick feature filters
  const featureStats = useMemo(() => {
    let rewardsCount = 0;
    let giftCardCount = 0;
    let bankCount = 0;
    let earnWithdrawCount = 0;
    let all2FACount = 0;
    let both2FACount = 0;
    let phoneOnly2FACount = 0;
    let emailOnly2FACount = 0;

    for (const cat of categories) {
      for (const item of cat.items) {
        const r = item.rewards;
        if (r?.hasRewardsOrPoints) rewardsCount++;
        if (r?.hasGiftCards) giftCardCount++;
        if (r?.isBankOrFinancial) bankCount++;
        if (r?.canEarn && r?.canWithdrawOrRedeem) earnWithdrawCount++;

        const has2FA =
          r &&
          ((r.twoFactorType && r.twoFactorType !== 'N/A' && r.twoFactorType !== 'None') ||
            r.isBankOrFinancial ||
            r.supportsPhone2FA === 'Yes' ||
            r.supportsEmail2FA === 'Yes');

        const isBoth =
          r?.twoFactorType === 'Both' ||
          (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'Yes');

        const isPhoneOnly =
          r?.twoFactorType === 'Phone Only' ||
          (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'No');

        const isEmailOnly =
          r?.twoFactorType === 'Email Only' ||
          (r?.supportsPhone2FA === 'No' && r?.supportsEmail2FA === 'Yes');

        if (has2FA) all2FACount++;
        if (isBoth) both2FACount++;
        if (isPhoneOnly) phoneOnly2FACount++;
        if (isEmailOnly) emailOnly2FACount++;
      }
    }

    return {
      rewardsCount,
      giftCardCount,
      bankCount,
      earnWithdrawCount,
      all2FACount,
      both2FACount,
      phoneOnly2FACount,
      emailOnly2FACount,
    };
  }, [categories]);

  const handleCopy = (content: string, type: string) => {
    navigator.clipboard.writeText(content);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handleDownloadCsv = () => {
    const headers = [
      'Category',
      'Domain',
      'Site_SubType',
      'Pasted_Context_Or_Count',
      'What_This_Site_Does',
      'Financial_App_SubType',
      'Financial_App_Details',
      'Tags',
      'Has_Rewards_Points',
      'Can_Earn',
      'Can_Withdraw_Redeem',
      'Rewards_Details',
      'Has_Gift_Cards',
      'Gift_Card_Details',
      'Is_Bank_Or_Financial',
      '2FA_Login_Support_Type',
      'Phone_Number_2FA',
      'Email_2FA',
      'Two_Factor_Details',
      'How_To_Log_In_Guide',
    ];

    const rows = [headers];
    for (const cat of categories) {
      for (const item of cat.items) {
        const r = item.rewards || {};
        const isBoth =
          r.twoFactorType === 'Both' ||
          (r.supportsPhone2FA === 'Yes' && r.supportsEmail2FA === 'Yes');
        const isPhoneOnly =
          r.twoFactorType === 'Phone Only' ||
          (r.supportsPhone2FA === 'Yes' && r.supportsEmail2FA === 'No');
        const isEmailOnly =
          r.twoFactorType === 'Email Only' ||
          (r.supportsPhone2FA === 'No' && r.supportsEmail2FA === 'Yes');

        let twoFactorTypeStr: string = r.twoFactorType || 'N/A';
        if (isBoth) twoFactorTypeStr = 'Both (Phone & Email)';
        else if (isPhoneOnly) twoFactorTypeStr = 'Phone Number Only';
        else if (isEmailOnly) twoFactorTypeStr = 'Email Only';

        const pastedContext =
          item.pastedLabel ||
          (item.pastedCount && item.pastedCount > 1 ? `${item.pastedCount} accounts/items` : '') ||
          (item.rawOccurrences && item.rawOccurrences > 1 ? `${item.rawOccurrences}x occurrences` : '');

        rows.push([
          `"${cat.name.replace(/"/g, '""')}"`,
          `"${item.domain.replace(/"/g, '""')}"`,
          `"${(item.siteSubType || r.financialSubType || '').replace(/"/g, '""')}"`,
          `"${pastedContext.replace(/"/g, '""')}"`,
          `"${item.description.replace(/"/g, '""')}"`,
          `"${(r.financialSubType || '').replace(/"/g, '""')}"`,
          `"${(r.financialDetails || '').replace(/"/g, '""')}"`,
          `"${(item.tags || []).join(', ').replace(/"/g, '""')}"`,
          `"${r.hasRewardsOrPoints ? 'Yes' : 'No'}"`,
          `"${r.canEarn ? 'Yes' : 'No'}"`,
          `"${r.canWithdrawOrRedeem ? 'Yes' : 'No'}"`,
          `"${(r.rewardsDetails || '').replace(/"/g, '""')}"`,
          `"${r.hasGiftCards ? 'Yes' : 'No'}"`,
          `"${(r.giftCardDetails || '').replace(/"/g, '""')}"`,
          `"${r.isBankOrFinancial ? 'Yes' : 'No'}"`,
          `"${twoFactorTypeStr.replace(/"/g, '""')}"`,
          `"${(r.supportsPhone2FA || 'N/A').replace(/"/g, '""')}"`,
          `"${(r.supportsEmail2FA || 'N/A').replace(/"/g, '""')}"`,
          `"${(r.twoFactorDetails || '').replace(/"/g, '""')}"`,
          `"${(r.loginVerificationGuide || '').replace(/"/g, '""')}"`,
        ]);
      }
    }
    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `domain_categorization_2fa_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="analysis-results-section" className="space-y-4">
      {/* 2FA Login Tracking Explanatory Header */}
      <div className="p-3.5 rounded-2xl bg-indigo-50/80 border border-indigo-200/80 flex items-start gap-3 shadow-2xs">
        <Lock className="w-4 h-4 text-indigo-700 shrink-0 mt-0.5" />
        <div className="text-xs text-indigo-950 space-y-1">
          <p className="font-semibold text-indigo-950">
            2FA Login Verification Guide & Method Logging
          </p>
          <p className="text-indigo-900/90 leading-relaxed">
            The system tracks whether accounts and banks accept <strong>Phone Number 2FA</strong> (SMS text / automated call),{' '}
            <strong>Email 2FA</strong> (one-time passcode / magic link), or <strong>Both</strong> when logging in.
            Click <em>"How to Log In"</em> on any website card or view the Table column to see the full step-by-step verification sequence.
          </p>
        </div>
      </div>

      {/* Results Header Card */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-bold text-zinc-900 tracking-tight">
                Categorization & 2FA Analysis Results
              </h2>
              <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                <Sparkles className="w-3 h-3 text-emerald-600" />
                <span>
                  {result.totalDomains} {result.totalDomains === 1 ? 'Domain' : 'Domains'}
                </span>
              </span>
            </div>
            <p className="text-xs text-zinc-500 mt-1">
              Classified into {categories.length} categories using {result.modelUsed}
            </p>
          </div>

          {/* View Mode Toggle & Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {onReanalyze && (
              <button
                type="button"
                id="reanalyze-btn"
                onClick={onReanalyze}
                className="inline-flex items-center space-x-1 px-2.5 py-1.5 text-xs font-medium text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors shadow-2xs"
                title="Re-run analysis"
              >
                <RefreshCw className="w-3.5 h-3.5 text-zinc-500" />
                <span>Re-run</span>
              </button>
            )}

            {/* Tab switchers */}
            <div className="inline-flex items-center p-1 bg-zinc-100 rounded-lg border border-zinc-200 text-xs font-medium">
              <button
                type="button"
                id="tab-cards-btn"
                onClick={() => setActiveTab('cards')}
                className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'cards'
                    ? 'bg-white text-zinc-900 shadow-2xs font-semibold'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Cards</span>
              </button>

              <button
                type="button"
                id="tab-table-btn"
                onClick={() => setActiveTab('table')}
                className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'table'
                    ? 'bg-white text-zinc-900 shadow-2xs font-semibold'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                <List className="w-3.5 h-3.5" />
                <span>Table</span>
              </button>

              <button
                type="button"
                id="tab-markdown-btn"
                onClick={() => setActiveTab('markdown')}
                className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'markdown'
                    ? 'bg-white text-zinc-900 shadow-2xs font-semibold'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Markdown</span>
              </button>
            </div>

            {/* Export buttons */}
            <button
              type="button"
              id="copy-markdown-btn"
              onClick={() => handleCopy(result.markdown, 'markdown')}
              className="inline-flex items-center space-x-1 px-3 py-1.5 text-xs font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors shadow-2xs"
            >
              {copiedType === 'markdown' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-zinc-500" />
                  <span>Copy Markdown</span>
                </>
              )}
            </button>

            <button
              type="button"
              id="export-csv-btn"
              onClick={handleDownloadCsv}
              className="inline-flex items-center space-x-1 px-3 py-1.5 text-xs font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-zinc-500" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Accurate Accounting Summary Strip */}
        <div className="pt-2 border-t border-zinc-100 flex flex-wrap items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-zinc-100 text-zinc-800 font-medium">
            📋 Pasted Inputs: <strong>{result.stats?.pastedLinesCount ?? result.totalDomains}</strong>
          </span>
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200/80 font-medium">
            ✨ Classified Targets: <strong>{totalItemsCount}</strong> (100% accounted for, 0 omissions)
          </span>
          {result.stats && result.stats.duplicateMentionsCount > 0 && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-50 text-amber-800 border border-amber-200/80 font-medium">
              🔁 Consolidated Repeats: <strong>{result.stats.duplicateMentionsCount}</strong>
            </span>
          )}
          {result.stats &&
            result.stats.totalInstancesOrAccounts !== undefined &&
            result.stats.totalInstancesOrAccounts > result.totalDomains && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-purple-50 text-purple-800 border border-purple-200/80 font-medium">
                🔢 Accounts/Items Logged: <strong>{result.stats.totalInstancesOrAccounts}</strong>
              </span>
            )}
        </div>

        {/* Feature Filters Pills */}
        <div className="pt-2 border-t border-zinc-100 flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mr-1">
            Filter by features:
          </span>
          <button
            type="button"
            id="filter-feature-all"
            onClick={() => setFeatureFilter('all')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === 'all'
                ? 'bg-zinc-900 text-white'
                : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
            }`}
          >
            All Websites ({totalItemsCount})
          </button>

          {/* 2FA: Both Phone & Email */}
          <button
            type="button"
            id="filter-feature-2fa-both"
            onClick={() => setFeatureFilter(featureFilter === '2fa-both' ? 'all' : '2fa-both')}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === '2fa-both'
                ? 'bg-indigo-700 text-white shadow-2xs'
                : 'bg-indigo-50 text-indigo-900 hover:bg-indigo-100 border border-indigo-200'
            }`}
          >
            <span>🔄 Both Phone & Email ({featureStats.both2FACount})</span>
          </button>

          {/* 2FA: Phone Only */}
          <button
            type="button"
            id="filter-feature-2fa-phone"
            onClick={() => setFeatureFilter(featureFilter === '2fa-phone' ? 'all' : '2fa-phone')}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === '2fa-phone'
                ? 'bg-blue-700 text-white shadow-2xs'
                : 'bg-blue-50 text-blue-900 hover:bg-blue-100 border border-blue-200'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            <span>Phone 2FA Only ({featureStats.phoneOnly2FACount})</span>
          </button>

          {/* 2FA: Email Only */}
          <button
            type="button"
            id="filter-feature-2fa-email"
            onClick={() => setFeatureFilter(featureFilter === '2fa-email' ? 'all' : '2fa-email')}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === '2fa-email'
                ? 'bg-purple-700 text-white shadow-2xs'
                : 'bg-purple-50 text-purple-900 hover:bg-purple-100 border border-purple-200'
            }`}
          >
            <Mail className="w-3 h-3" />
            <span>Email 2FA Only ({featureStats.emailOnly2FACount})</span>
          </button>

          {/* Rewards & Points */}
          <button
            type="button"
            id="filter-feature-rewards"
            onClick={() => setFeatureFilter(featureFilter === 'rewards' ? 'all' : 'rewards')}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === 'rewards'
                ? 'bg-emerald-700 text-white'
                : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            <Gift className="w-3 h-3" />
            <span>Rewards ({featureStats.rewardsCount})</span>
          </button>

          {/* Gift Cards */}
          <button
            type="button"
            id="filter-feature-giftcards"
            onClick={() => setFeatureFilter(featureFilter === 'giftcards' ? 'all' : 'giftcards')}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === 'giftcards'
                ? 'bg-amber-700 text-white'
                : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            <CreditCard className="w-3 h-3" />
            <span>Gift Cards ({featureStats.giftCardCount})</span>
          </button>

          {/* Earn & Withdraw */}
          <button
            type="button"
            id="filter-feature-earn-withdraw"
            onClick={() => setFeatureFilter(featureFilter === 'earn-withdraw' ? 'all' : 'earn-withdraw')}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === 'earn-withdraw'
                ? 'bg-teal-700 text-white'
                : 'bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200'
            }`}
          >
            <Coins className="w-3 h-3" />
            <span>Earn & Withdraw ({featureStats.earnWithdrawCount})</span>
          </button>

          {/* Banks */}
          <button
            type="button"
            id="filter-feature-banks"
            onClick={() => setFeatureFilter(featureFilter === 'banks' ? 'all' : 'banks')}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
              featureFilter === 'banks'
                ? 'bg-indigo-700 text-white'
                : 'bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border border-indigo-200'
            }`}
          >
            <ShieldCheck className="w-3 h-3" />
            <span>Banks ({featureStats.bankCount})</span>
          </button>
        </div>

        {/* Search & Category Filter Bar */}
        {activeTab !== 'markdown' && (
          <div className="pt-2 border-t border-zinc-100 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="search-filter-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search domain, description, email 2FA, phone 2FA, or login guide..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-zinc-700"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category Chips */}
            <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
              {categoryNames.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  id={`filter-cat-${cat.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs px-2.5 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                    selectedCategory === cat
                      ? 'bg-zinc-900 text-white'
                      : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
                  }`}
                >
                  {cat === 'all' ? `All Categories (${totalItemsCount})` : cat}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Cards View Tab */}
      {activeTab === 'cards' && (
        <div className="space-y-4">
          {filteredCategories.map((category) => (
            <CategoryCard
              key={category.id || category.name}
              category={category}
              searchFilter={searchQuery}
              featureFilter={featureFilter}
            />
          ))}
        </div>
      )}

      {/* Table View Tab */}
      {activeTab === 'table' && (
        <div className="bg-white border border-zinc-200 rounded-2xl overflow-hidden shadow-2xs">
          <div className="overflow-x-auto max-h-[650px]">
            <table className="w-full text-left text-xs text-zinc-700 border-collapse">
              <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-900 font-semibold sticky top-0 z-10">
                <tr>
                  <th className="px-4 py-3">Domain</th>
                  <th className="px-4 py-3">Category & Type</th>
                  <th className="px-4 py-3 min-w-[280px]">What This Site Does & Financial Breakdown</th>
                  <th className="px-4 py-3">Rewards & Points</th>
                  <th className="px-4 py-3">Gift Cards</th>
                  <th className="px-4 py-3 min-w-[280px]">2FA Login Verification (Phone vs Email)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100">
                {filteredCategories.flatMap((cat) =>
                  cat.items
                    .filter((item) => {
                      const r = item.rewards;
                      const has2FA =
                        r &&
                        ((r.twoFactorType && r.twoFactorType !== 'N/A' && r.twoFactorType !== 'None') ||
                          r.isBankOrFinancial ||
                          r.supportsPhone2FA === 'Yes' ||
                          r.supportsEmail2FA === 'Yes');

                      const isBoth =
                        r?.twoFactorType === 'Both' ||
                        (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'Yes');

                      const isPhoneOnly =
                        r?.twoFactorType === 'Phone Only' ||
                        (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'No');

                      const isEmailOnly =
                        r?.twoFactorType === 'Email Only' ||
                        (r?.supportsPhone2FA === 'No' && r?.supportsEmail2FA === 'Yes');

                      // Feature filter
                      if (featureFilter === 'rewards' && !r?.hasRewardsOrPoints) return false;
                      if (featureFilter === 'giftcards' && !r?.hasGiftCards) return false;
                      if (featureFilter === 'banks' && !r?.isBankOrFinancial) return false;
                      if (featureFilter === 'earn-withdraw' && (!r?.canEarn || !r?.canWithdrawOrRedeem)) return false;
                      if (featureFilter === 'all-2fa' && !has2FA) return false;
                      if (featureFilter === '2fa-both' && !isBoth) return false;
                      if (featureFilter === '2fa-phone' && !isPhoneOnly) return false;
                      if (featureFilter === '2fa-email' && !isEmailOnly) return false;

                      if (!searchQuery.trim()) return true;
                      const q = searchQuery.toLowerCase();
                      return (
                        item.domain.toLowerCase().includes(q) ||
                        item.siteSubType?.toLowerCase().includes(q) ||
                        item.description.toLowerCase().includes(q) ||
                        item.tags?.some((t) => t.toLowerCase().includes(q)) ||
                        r?.financialSubType?.toLowerCase().includes(q) ||
                        r?.financialDetails?.toLowerCase().includes(q) ||
                        r?.rewardsDetails?.toLowerCase().includes(q) ||
                        r?.giftCardDetails?.toLowerCase().includes(q) ||
                        r?.twoFactorDetails?.toLowerCase().includes(q) ||
                        r?.loginVerificationGuide?.toLowerCase().includes(q) ||
                        r?.twoFactorType?.toLowerCase().includes(q)
                      );
                    })
                    .map((item) => {
                      const r = item.rewards;
                      const subTypeBadge = item.siteSubType || r?.financialSubType;
                      const hasFinancialBreakdown = Boolean(
                        r && (r.isBankOrFinancial || r.financialDetails || r.financialSubType)
                      );
                      const isBoth =
                        r?.twoFactorType === 'Both' ||
                        (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'Yes');
                      const isPhoneOnly =
                        r?.twoFactorType === 'Phone Only' ||
                        (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'No');
                      const isEmailOnly =
                        r?.twoFactorType === 'Email Only' ||
                        (r?.supportsPhone2FA === 'No' && r?.supportsEmail2FA === 'Yes');
                      const isAppKey = r?.twoFactorType === 'App/Security Key';

                      const isGuideOpen = expandedTableGuides[item.domain] ?? false;

                      return (
                        <tr key={item.domain} className="hover:bg-zinc-50/80 transition-colors">
                          <td className="px-4 py-3 font-mono text-zinc-900 whitespace-nowrap">
                            <div className="flex flex-col gap-0.5">
                              <a
                                href={`https://${item.domain}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="font-bold hover:underline hover:text-emerald-700"
                              >
                                {item.domain}
                              </a>
                              {item.pastedLabel ? (
                                <span className="text-[10px] font-sans font-semibold text-purple-700">
                                  📋 {item.pastedLabel}
                                </span>
                              ) : item.pastedCount && item.pastedCount > 1 ? (
                                <span className="text-[10px] font-sans font-semibold text-purple-700">
                                  📋 {item.pastedCount} accounts/items
                                </span>
                              ) : item.rawOccurrences && item.rawOccurrences > 1 ? (
                                <span className="text-[10px] font-sans font-semibold text-amber-700">
                                  🔁 {item.rawOccurrences}x pasted
                                </span>
                              ) : null}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-zinc-600 whitespace-nowrap">
                            <div className="flex flex-col items-start gap-1">
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-zinc-100 text-zinc-700">
                                {cat.name}
                              </span>
                              {subTypeBadge && (
                                <span
                                  className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold border ${
                                    r?.isBankOrFinancial
                                      ? 'bg-sky-50 text-sky-900 border-sky-200'
                                      : 'bg-zinc-900 text-white border-zinc-800'
                                  }`}
                                >
                                  {r?.isBankOrFinancial ? `🏦 ${subTypeBadge}` : subTypeBadge}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-zinc-700 leading-relaxed min-w-[280px] space-y-1.5">
                            <p className="text-zinc-800">{item.description}</p>
                            {hasFinancialBreakdown && (
                              <div className="p-2 rounded-lg bg-sky-50/90 border border-sky-200 text-[11px] text-sky-950 space-y-0.5">
                                <div className="font-semibold text-sky-950">
                                  🏦 Financial Type: {r?.financialSubType || item.siteSubType || 'Financial Service'}
                                </div>
                                {r?.financialDetails && (
                                  <p className="text-sky-900/90 leading-snug">{r.financialDetails}</p>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3 text-zinc-700 min-w-[180px]">
                            {r?.hasRewardsOrPoints ? (
                              <div className="space-y-1">
                                <div className="flex items-center gap-1">
                                  <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                                    Earn: {r.canEarn ? 'Yes' : 'No'}
                                  </span>
                                  <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                                    Redeem: {r.canWithdrawOrRedeem ? 'Yes' : 'No'}
                                  </span>
                                </div>
                                {r.rewardsDetails && (
                                  <p className="text-[11px] text-zinc-500 leading-tight">
                                    {r.rewardsDetails}
                                  </p>
                                )}
                              </div>
                            ) : (
                              <span className="text-zinc-400 italic text-[11px]">None</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-zinc-700 min-w-[160px]">
                            {r?.hasGiftCards ? (
                              <div>
                                <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-amber-100 text-amber-900">
                                  Yes
                                </span>
                                {r.giftCardDetails && (
                                  <p className="text-[11px] text-zinc-500 leading-tight mt-1">
                                    {r.giftCardDetails}
                                  </p>
                                )}
                              </div>
                            ) : (
                              <span className="text-zinc-400 italic text-[11px]">No</span>
                            )}
                          </td>
                          {/* 2FA Login Verification Column */}
                          <td className="px-4 py-3 text-zinc-700 min-w-[280px]">
                            {r && (isBoth || isPhoneOnly || isEmailOnly || isAppKey || r.isBankOrFinancial) ? (
                              <div className="space-y-1.5">
                                {/* Type Badge */}
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  {isBoth && (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-600 text-white">
                                      🔄 Both Phone & Email
                                    </span>
                                  )}
                                  {isPhoneOnly && (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600 text-white">
                                      📱 Phone Only
                                    </span>
                                  )}
                                  {isEmailOnly && (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-600 text-white">
                                      ✉️ Email Only
                                    </span>
                                  )}
                                  {isAppKey && (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800 text-white">
                                      🛡️ App / Key
                                    </span>
                                  )}
                                </div>

                                {/* Channel Breakdown */}
                                <div className="flex items-center gap-1.5 flex-wrap text-[10px]">
                                  <span
                                    className={`px-1.5 py-0.5 rounded font-medium ${
                                      r.supportsPhone2FA === 'Yes'
                                        ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                        : 'bg-zinc-100 text-zinc-600'
                                    }`}
                                  >
                                    Phone: {r.supportsPhone2FA === 'Yes' ? '✓ Works' : r.supportsPhone2FA || 'No'}
                                  </span>
                                  <span
                                    className={`px-1.5 py-0.5 rounded font-medium ${
                                      r.supportsEmail2FA === 'Yes'
                                        ? 'bg-purple-50 text-purple-800 border border-purple-200'
                                        : 'bg-zinc-100 text-zinc-600'
                                    }`}
                                  >
                                    Email: {r.supportsEmail2FA === 'Yes' ? '✓ Works' : r.supportsEmail2FA || 'No'}
                                  </span>
                                </div>

                                {r.twoFactorDetails && (
                                  <p className="text-[11px] text-zinc-600 leading-tight">
                                    {r.twoFactorDetails}
                                  </p>
                                )}

                                {/* Step-by-Step Login Guide */}
                                {r.loginVerificationGuide && (
                                  <div className="pt-1">
                                    <button
                                      type="button"
                                      onClick={() => toggleTableGuide(item.domain)}
                                      className="inline-flex items-center gap-1 text-[10px] font-semibold text-indigo-700 hover:text-indigo-900"
                                    >
                                      <HelpCircle className="w-2.5 h-2.5" />
                                      <span>{isGuideOpen ? 'Hide Steps' : 'View Login Steps'}</span>
                                    </button>
                                    {isGuideOpen && (
                                      <div className="mt-1 p-2 rounded bg-indigo-50/80 border border-indigo-200/80 text-[10px] text-indigo-950 font-sans">
                                        <p className="font-semibold text-indigo-950 mb-0.5">🔑 How to Log In:</p>
                                        <p>{r.loginVerificationGuide}</p>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <span className="text-zinc-400 italic text-[11px]">N/A</span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Markdown View Tab */}
      {activeTab === 'markdown' && (
        <div className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-zinc-700 uppercase tracking-wider">
              Markdown Output (with Rewards, Gift Cards, and 2FA Login Method Logging)
            </span>
            <button
              type="button"
              id="copy-raw-markdown-btn"
              onClick={() => handleCopy(result.markdown, 'raw-markdown')}
              className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-medium bg-zinc-100 hover:bg-zinc-200 text-zinc-800 transition-colors"
            >
              {copiedType === 'raw-markdown' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Copied to clipboard</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-zinc-600" />
                  <span>Copy Markdown</span>
                </>
              )}
            </button>
          </div>
          <pre className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl text-xs font-mono text-zinc-800 whitespace-pre-wrap leading-relaxed overflow-x-auto max-h-[500px]">
            {result.markdown}
          </pre>
        </div>
      )}
    </div>
  );
}
