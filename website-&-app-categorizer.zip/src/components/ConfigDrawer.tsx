import { useState } from 'react';
import { X, Key, Cpu, ShieldCheck, ExternalLink, HelpCircle } from 'lucide-react';

interface ConfigDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  provider: 'gemini' | 'openai';
  setProvider: (p: 'gemini' | 'openai') => void;
  model: string;
  setModel: (m: string) => void;
  apiKey: string;
  setApiKey: (k: string) => void;
  serverHasGeminiKey: boolean;
}

export function ConfigDrawer({
  isOpen,
  onClose,
  provider,
  setProvider,
  model,
  setModel,
  apiKey,
  setApiKey,
  serverHasGeminiKey,
}: ConfigDrawerProps) {
  const [showKey, setShowKey] = useState(false);

  if (!isOpen) return null;

  const handleProviderChange = (newProvider: 'gemini' | 'openai') => {
    setProvider(newProvider);
    if (newProvider === 'gemini') {
      setModel('gemini-3-flash-preview');
    } else {
      setModel('gpt-4o-mini');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex justify-end">
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col transform transition-transform duration-300 ease-in-out border-l border-zinc-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-zinc-700" />
            <h2 className="text-base font-semibold text-zinc-900">Configuration</h2>
          </div>
          <button
            id="close-config-drawer-button"
            onClick={onClose}
            className="p-1 rounded-md text-zinc-400 hover:text-zinc-600 hover:bg-zinc-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 flex-1 overflow-y-auto">
          {/* Provider Selection */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wider">
              AI Provider
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                id="select-gemini-provider-btn"
                onClick={() => handleProviderChange('gemini')}
                className={`flex flex-col items-start p-3 rounded-xl border text-left transition-all ${
                  provider === 'gemini'
                    ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20'
                    : 'border-zinc-200 hover:border-zinc-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-semibold text-xs text-zinc-900">Google Gemini</span>
                  {provider === 'gemini' && (
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                  )}
                </div>
                <span className="text-[11px] text-zinc-500 mt-1">
                  Built-in server key ready
                </span>
              </button>

              <button
                type="button"
                id="select-openai-provider-btn"
                onClick={() => handleProviderChange('openai')}
                className={`flex flex-col items-start p-3 rounded-xl border text-left transition-all ${
                  provider === 'openai'
                    ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20'
                    : 'border-zinc-200 hover:border-zinc-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-semibold text-xs text-zinc-900">OpenAI</span>
                  {provider === 'openai' && (
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                  )}
                </div>
                <span className="text-[11px] text-zinc-500 mt-1">
                  Streamlit original default
                </span>
              </button>
            </div>
          </div>

          {/* Model Selection */}
          <div className="space-y-2">
            <label htmlFor="model-select" className="text-xs font-semibold text-zinc-700 uppercase tracking-wider flex items-center justify-between">
              <span>Choose AI Model</span>
            </label>
            <select
              id="model-select"
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full px-3 py-2.5 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            >
              {provider === 'gemini' ? (
                <>
                  <option value="gemini-3-flash-preview">gemini-3-flash-preview (Recommended, fast & latest)</option>
                  <option value="gemini-2.5-flash">gemini-2.5-flash (High-availability Flash)</option>
                  <option value="gemini-3.1-flash-lite-preview">gemini-3.1-flash-lite-preview (Lightweight)</option>
                </>
              ) : (
                <>
                  <option value="gpt-4o-mini">gpt-4o-mini (Fast & efficient)</option>
                  <option value="gpt-4o">gpt-4o (High precision)</option>
                </>
              )}
            </select>
            <p className="text-[11px] text-zinc-500">
              {provider === 'gemini'
                ? 'Gemini models with automatic failover fallback if any model experiences temporary high demand.'
                : 'Matches the models in the original Streamlit code.'}
            </p>
          </div>

          {/* API Key Input */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="custom-api-key-input" className="text-xs font-semibold text-zinc-700 uppercase tracking-wider flex items-center space-x-1.5">
                <Key className="w-3.5 h-3.5 text-zinc-500" />
                <span>
                  {provider === 'openai' ? 'OpenAI API Key' : 'API Key (Optional)'}
                </span>
              </label>
              {provider === 'gemini' && serverHasGeminiKey && (
                <span className="inline-flex items-center text-[11px] text-emerald-600 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                  Pre-configured in environment
                </span>
              )}
            </div>

            <div className="relative">
              <input
                id="custom-api-key-input"
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder={
                  provider === 'openai'
                    ? 'sk-...'
                    : serverHasGeminiKey
                    ? 'Default server key active (or paste custom key)'
                    : 'AIzaSy...'
                }
                className="w-full pr-16 pl-3 py-2.5 bg-zinc-50 border border-zinc-300 rounded-lg text-sm text-zinc-900 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
              />
              <button
                type="button"
                id="toggle-show-key-button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-zinc-500 hover:text-zinc-800 px-1.5 py-0.5 rounded"
              >
                {showKey ? 'Hide' : 'Show'}
              </button>
            </div>

            <p className="text-[11px] text-zinc-500">
              {provider === 'openai' ? (
                <span>
                  Get a key from{' '}
                  <a
                    href="https://platform.openai.com/api-keys"
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-600 hover:underline inline-flex items-center"
                  >
                    platform.openai.com <ExternalLink className="w-2.5 h-2.5 ml-0.5" />
                  </a>
                  . Saved in your local browser session.
                </span>
              ) : (
                <span>
                  Google Gemini works out-of-the-box using the server environment key. You can also supply a custom key if desired.
                </span>
              )}
            </p>
          </div>

          {/* Quick Info Box */}
          <div className="p-3.5 rounded-xl bg-zinc-50 border border-zinc-200 text-xs text-zinc-600 space-y-1.5">
            <div className="flex items-center space-x-1.5 font-medium text-zinc-800">
              <HelpCircle className="w-4 h-4 text-emerald-600" />
              <span>How classification works</span>
            </div>
            <p className="text-[11px] leading-relaxed text-zinc-600">
              Messy input notes are scanned with a robust regex domain extractor. Valid domains are deduplicated and categorized by AI with a punchy, one-sentence description of each site.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-zinc-200 bg-zinc-50 flex items-center justify-between">
          <button
            type="button"
            id="reset-config-defaults-btn"
            onClick={() => {
              setProvider('gemini');
              setModel('gemini-3.8-flash');
              setApiKey('');
            }}
            className="text-xs text-zinc-500 hover:text-zinc-800 underline"
          >
            Reset to defaults
          </button>
          <button
            type="button"
            id="save-config-done-btn"
            onClick={onClose}
            className="px-4 py-2 bg-zinc-900 text-white rounded-lg text-xs font-semibold hover:bg-zinc-800 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
