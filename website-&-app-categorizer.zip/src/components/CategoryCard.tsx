import { useState } from 'react';
import {
  ExternalLink,
  Copy,
  Check,
  Folder,
  Gift,
  CreditCard,
  ShieldCheck,
  Smartphone,
  Mail,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Landmark,
} from 'lucide-react';
import { DomainCategory } from '../types';

export type FeatureFilterType =
  | 'all'
  | 'rewards'
  | 'giftcards'
  | 'banks'
  | 'earn-withdraw'
  | 'all-2fa'
  | '2fa-both'
  | '2fa-phone'
  | '2fa-email';

interface CategoryCardProps {
  category: DomainCategory;
  searchFilter: string;
  featureFilter?: FeatureFilterType;
}

export function CategoryCard({ category, searchFilter, featureFilter = 'all' }: CategoryCardProps) {
  const [copiedDomain, setCopiedDomain] = useState<string | null>(null);
  const [expandedGuides, setExpandedGuides] = useState<Record<string, boolean>>({});

  const toggleGuide = (domain: string) => {
    setExpandedGuides((prev) => ({ ...prev, [domain]: !prev[domain] }));
  };

  const filteredItems = category.items.filter((item) => {
    const r = item.rewards;
    const has2FA =
      r &&
      ((r.twoFactorType && r.twoFactorType !== 'N/A' && r.twoFactorType !== 'None') ||
        r.isBankOrFinancial ||
        r.supportsPhone2FA === 'Yes' ||
        r.supportsEmail2FA === 'Yes');

    const isBoth =
      r?.twoFactorType === 'Both' ||
      (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'Yes');

    const isPhoneOnly =
      r?.twoFactorType === 'Phone Only' ||
      (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'No');

    const isEmailOnly =
      r?.twoFactorType === 'Email Only' ||
      (r?.supportsPhone2FA === 'No' && r?.supportsEmail2FA === 'Yes');

    // Feature filter
    if (featureFilter === 'rewards' && !r?.hasRewardsOrPoints) return false;
    if (featureFilter === 'giftcards' && !r?.hasGiftCards) return false;
    if (featureFilter === 'banks' && !r?.isBankOrFinancial) return false;
    if (featureFilter === 'earn-withdraw' && (!r?.canEarn || !r?.canWithdrawOrRedeem)) return false;
    if (featureFilter === 'all-2fa' && !has2FA) return false;
    if (featureFilter === '2fa-both' && !isBoth) return false;
    if (featureFilter === '2fa-phone' && !isPhoneOnly) return false;
    if (featureFilter === '2fa-email' && !isEmailOnly) return false;

    // Search query
    if (!searchFilter.trim()) return true;
    const q = searchFilter.toLowerCase();
    const domainMatch = item.domain.toLowerCase().includes(q);
    const subTypeMatch = item.siteSubType?.toLowerCase().includes(q);
    const descMatch = item.description.toLowerCase().includes(q);
    const tagMatch = item.tags?.some((t) => t.toLowerCase().includes(q));
    const finSubTypeMatch = r?.financialSubType?.toLowerCase().includes(q);
    const finDetailsMatch = r?.financialDetails?.toLowerCase().includes(q);
    const rewardsMatch = r?.rewardsDetails?.toLowerCase().includes(q);
    const giftCardMatch = r?.giftCardDetails?.toLowerCase().includes(q);
    const twoFactorMatch = r?.twoFactorDetails?.toLowerCase().includes(q);
    const guideMatch = r?.loginVerificationGuide?.toLowerCase().includes(q);
    const typeMatch = r?.twoFactorType?.toLowerCase().includes(q);

    return (
      domainMatch ||
      subTypeMatch ||
      descMatch ||
      tagMatch ||
      finSubTypeMatch ||
      finDetailsMatch ||
      rewardsMatch ||
      giftCardMatch ||
      twoFactorMatch ||
      guideMatch ||
      typeMatch
    );
  });

  if (filteredItems.length === 0) {
    return null;
  }

  const handleCopy = (domain: string) => {
    navigator.clipboard.writeText(domain);
    setCopiedDomain(domain);
    setTimeout(() => setCopiedDomain(null), 2000);
  };

  return (
    <div
      id={`category-card-${category.id}`}
      className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-2xs hover:shadow-xs transition-shadow"
    >
      {/* Category Header */}
      <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-zinc-100">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-zinc-100 text-zinc-700 flex items-center justify-center font-semibold">
            <Folder className="w-4 h-4 text-zinc-600" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-zinc-900 leading-tight">
              {category.name}
            </h3>
            {category.description && (
              <p className="text-xs text-zinc-500 mt-0.5">{category.description}</p>
            )}
          </div>
        </div>
        <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-zinc-100 text-zinc-700 border border-zinc-200">
          {filteredItems.length} {filteredItems.length === 1 ? 'site' : 'sites'}
        </span>
      </div>

      {/* Domain items list */}
      <div className="divide-y divide-zinc-100">
        {filteredItems.map((item) => {
          const isCopied = copiedDomain === item.domain;
          const r = item.rewards;
          const subTypeBadge = item.siteSubType || r?.financialSubType;
          const hasFinancialBreakdown = Boolean(
            r && (r.isBankOrFinancial || r.financialDetails || r.financialSubType)
          );
          const hasSpecialBadges =
            r &&
            (hasFinancialBreakdown ||
              r.hasRewardsOrPoints ||
              r.hasGiftCards ||
              r.supportsPhone2FA === 'Yes' ||
              r.supportsEmail2FA === 'Yes' ||
              (r.twoFactorType && r.twoFactorType !== 'N/A' && r.twoFactorType !== 'None'));

          const isGuideOpen = expandedGuides[item.domain] ?? false;

          // Determine 2FA type details
          const isBoth =
            r?.twoFactorType === 'Both' ||
            (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'Yes');
          const isPhoneOnly =
            r?.twoFactorType === 'Phone Only' ||
            (r?.supportsPhone2FA === 'Yes' && r?.supportsEmail2FA === 'No');
          const isEmailOnly =
            r?.twoFactorType === 'Email Only' ||
            (r?.supportsPhone2FA === 'No' && r?.supportsEmail2FA === 'Yes');
          const isAppKey = r?.twoFactorType === 'App/Security Key';

          const has2FAInfo =
            r &&
            (isBoth ||
              isPhoneOnly ||
              isEmailOnly ||
              isAppKey ||
              r.isBankOrFinancial ||
              r.supportsPhone2FA === 'Yes' ||
              r.supportsEmail2FA === 'Yes');

          return (
            <div
              key={item.domain}
              id={`item-${item.domain.replace(/[^a-z0-9]/gi, '-')}`}
              className="py-3.5 first:pt-1 last:pb-1 flex flex-col sm:flex-row sm:items-start justify-between gap-3 group"
            >
              <div className="space-y-1.5 pr-2 flex-1">
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  <span className="font-bold text-sm text-zinc-950 tracking-tight font-mono">
                    {item.domain}
                  </span>
                  {subTypeBadge && (
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border shadow-2xs ${
                        r?.isBankOrFinancial
                          ? 'bg-sky-50 text-sky-900 border-sky-200'
                          : 'bg-zinc-900 text-white border-zinc-800'
                      }`}
                    >
                      {r?.isBankOrFinancial ? `🏦 ${subTypeBadge}` : subTypeBadge}
                    </span>
                  )}
                  {item.pastedLabel ? (
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-purple-50 text-purple-700 border border-purple-200 shadow-2xs">
                      📋 {item.pastedLabel}
                    </span>
                  ) : item.pastedCount && item.pastedCount > 1 ? (
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-purple-50 text-purple-700 border border-purple-200 shadow-2xs">
                      📋 {item.pastedCount} accounts/items
                    </span>
                  ) : item.rawOccurrences && item.rawOccurrences > 1 ? (
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 shadow-2xs">
                      🔁 {item.rawOccurrences}x pasted
                    </span>
                  ) : null}
                  {item.tags?.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-zinc-100 text-zinc-600 border border-zinc-200/80"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Brief explanation of what the site does */}
                <p className="text-sm text-zinc-700 leading-relaxed">
                  <span className="font-semibold text-zinc-900">What this site does: </span>
                  {item.description}
                </p>

                {/* Rewards, Financial Breakdown, Gift Cards, and 2FA Badges */}
                {hasSpecialBadges && (
                  <div className="pt-2 flex flex-col gap-1.5">
                    {/* Financial App Classification & Detailed Breakdown */}
                    {hasFinancialBreakdown && (
                      <div className="p-2.5 rounded-lg bg-sky-50/80 border border-sky-200/80 text-xs text-sky-950 flex items-start gap-2">
                        <Landmark className="w-3.5 h-3.5 text-sky-700 shrink-0 mt-0.5" />
                        <div className="leading-snug space-y-0.5">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-semibold text-sky-950">
                              Financial App Breakdown:
                            </span>
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-700 text-white">
                              {r.financialSubType || item.siteSubType || 'Bank / Financial Platform'}
                            </span>
                          </div>
                          <p className="text-sky-900 text-[11px] leading-relaxed">
                            {r.financialDetails ||
                              `${item.description} Supports financial account balances, payment methods, or asset transfers.`}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Rewards & Points info */}
                    {r.hasRewardsOrPoints && (
                      <div className="p-2 rounded-lg bg-emerald-50/70 border border-emerald-200/70 text-xs text-emerald-950 flex items-start gap-2">
                        <Gift className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <div className="leading-snug">
                          <span className="font-semibold text-emerald-900">
                            Rewards & Points:{' '}
                          </span>
                          <span className="inline-flex items-center gap-1 font-medium text-[11px] px-1.5 py-0.2 rounded bg-emerald-100/80 text-emerald-800 mr-1.5">
                            Earn: {r.canEarn ? '✓ Yes' : '✗ No'}
                          </span>
                          <span className="inline-flex items-center gap-1 font-medium text-[11px] px-1.5 py-0.2 rounded bg-emerald-100/80 text-emerald-800 mr-1.5">
                            Redeem/Withdraw: {r.canWithdrawOrRedeem ? '✓ Yes' : '✗ No'}
                          </span>
                          {r.rewardsDetails && (
                            <span className="text-emerald-800 text-[11px] mt-0.5 block sm:inline">
                              {r.rewardsDetails}
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Gift Cards info */}
                    {r.hasGiftCards && (
                      <div className="p-2 rounded-lg bg-amber-50/70 border border-amber-200/70 text-xs text-amber-950 flex items-start gap-2">
                        <CreditCard className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <div className="leading-snug">
                          <span className="font-semibold text-amber-900">Gift Cards: </span>
                          <span className="text-amber-800 text-[11px]">
                            {r.giftCardDetails || 'Sells gift cards or enables points-to-gift-card redemption'}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* 2FA Login Verification info */}
                    {has2FAInfo && (
                      <div className="p-2.5 rounded-xl bg-indigo-50/70 border border-indigo-200/70 text-xs text-indigo-950 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-start gap-2">
                            <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                            <div className="leading-snug">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-semibold text-indigo-950">
                                  2FA Login Verification:
                                </span>
                                {/* Method Type Badge */}
                                {isBoth && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-600 text-white shadow-2xs">
                                    🔄 Both Phone & Email 2FA
                                  </span>
                                )}
                                {isPhoneOnly && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600 text-white shadow-2xs">
                                    📱 Phone 2FA Only
                                  </span>
                                )}
                                {isEmailOnly && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-600 text-white shadow-2xs">
                                    ✉️ Email 2FA Only
                                  </span>
                                )}
                                {isAppKey && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800 text-white shadow-2xs">
                                    🛡️ App / Hardware Key
                                  </span>
                                )}
                              </div>

                              {/* Breakdown Pills: Phone vs Email */}
                              <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                                <span
                                  className={`inline-flex items-center gap-1 font-medium text-[11px] px-2 py-0.5 rounded-md ${
                                    r.supportsPhone2FA === 'Yes'
                                      ? 'bg-blue-100 text-blue-900 border border-blue-200'
                                      : 'bg-zinc-100 text-zinc-600'
                                  }`}
                                >
                                  <Smartphone className="w-3 h-3 text-blue-700" />
                                  Phone Number: {r.supportsPhone2FA === 'Yes' ? '✓ Works' : r.supportsPhone2FA || 'No'}
                                </span>

                                <span
                                  className={`inline-flex items-center gap-1 font-medium text-[11px] px-2 py-0.5 rounded-md ${
                                    r.supportsEmail2FA === 'Yes'
                                      ? 'bg-purple-100 text-purple-900 border border-purple-200'
                                      : 'bg-zinc-100 text-zinc-600'
                                  }`}
                                >
                                  <Mail className="w-3 h-3 text-purple-700" />
                                  Email 2FA: {r.supportsEmail2FA === 'Yes' ? '✓ Works' : r.supportsEmail2FA || 'No'}
                                </span>

                                {r.isBankOrFinancial && (
                                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-100 text-indigo-800">
                                    Bank / Financial Institution
                                  </span>
                                )}
                              </div>

                              {r.twoFactorDetails && (
                                <p className="text-indigo-900/80 text-[11px] mt-1.5 leading-relaxed">
                                  {r.twoFactorDetails}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* How to Log In Toggle Button */}
                          {r.loginVerificationGuide && (
                            <button
                              type="button"
                              onClick={() => toggleGuide(item.domain)}
                              className="shrink-0 inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium bg-indigo-100/90 text-indigo-900 hover:bg-indigo-200 transition-colors"
                              title="Toggle step-by-step login instructions"
                            >
                              <HelpCircle className="w-3 h-3" />
                              <span>{isGuideOpen ? 'Hide Login Steps' : 'How to Log In'}</span>
                              {isGuideOpen ? (
                                <ChevronUp className="w-3 h-3" />
                              ) : (
                                <ChevronDown className="w-3 h-3" />
                              )}
                            </button>
                          )}
                        </div>

                        {/* Collapsible How-To-Log-In Step-by-Step Guide */}
                        {isGuideOpen && r.loginVerificationGuide && (
                          <div className="mt-2 p-2.5 rounded-lg bg-white/90 border border-indigo-200 text-xs text-indigo-950 shadow-2xs space-y-1">
                            <div className="flex items-center gap-1 font-semibold text-indigo-950 text-[11px]">
                              <span>🔑 Step-by-Step Login Verification Guide:</span>
                            </div>
                            <p className="text-[11px] text-zinc-700 leading-relaxed font-sans">
                              {r.loginVerificationGuide}
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-1 sm:opacity-75 sm:group-hover:opacity-100 transition-opacity shrink-0 self-start sm:self-center">
                <button
                  type="button"
                  id={`copy-domain-${item.domain.replace(/[^a-z0-9]/gi, '-')}`}
                  onClick={() => handleCopy(item.domain)}
                  className="p-1.5 rounded-md text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 transition-colors"
                  title="Copy domain"
                >
                  {isCopied ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>

                <a
                  href={`https://${item.domain}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  id={`visit-domain-${item.domain.replace(/[^a-z0-9]/gi, '-')}`}
                  className="p-1.5 rounded-md text-zinc-400 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                  title={`Visit ${item.domain}`}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
