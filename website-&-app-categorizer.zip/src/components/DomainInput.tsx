import { useState, useMemo } from 'react';
import { extractDomainsDetailed, DomainExtractionResult } from '../utils/domainExtractor';
import { AnalysisStats } from '../types';
import {
  Sparkles,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Copy,
  Hash,
  Globe,
  Layers,
  Server
} from 'lucide-react';

interface DomainInputProps {
  rawText: string;
  setRawText: (text: string) => void;
  onAnalyze: (
    detectedDomains: string[],
    metadataMap?: Record<string, { count: number; label?: string; occurrences: number }>,
    stats?: AnalysisStats
  ) => void;
  isLoading: boolean;
  provider: 'gemini' | 'openai';
  hasApiKey: boolean;
  onOpenConfig: () => void;
}

const SAMPLE_PRESETS = [
  {
    name: 'Sample Logs with Accounts',
    text: `chase.com 12 accounts
wellsfargo.com 4 accounts
aa.com 8 accounts
amazon.com 6 accounts
192.168.217.50:446
booking.com 2 sessions
stripe.com 1 checkout
github.com team repository`,
  },
  {
    name: 'Rewards, Gift Cards & Banks',
    text: `chase.com (Chase Ultimate Rewards & checking)
starbucks.com (Stars loyalty & gift card reload)
amazon.com (Gift card store & points)
swagbucks.com (Earn points for gift cards & Paypal cash)
wellsfargo.com (Online banking login)
aa.com (American Airlines AAdvantage miles)
target.com (Circle rewards & gift cards)`,
  },
  {
    name: 'Dev & Infrastructure (with IPs)',
    text: `Audit log:
https://github.com/org/repo
vercel.com deployment url
aws.amazon.com cloud instance
cloudflare.com dns zone
10.0.4.12:3000 (internal microservice)
datadog.com monitoring agent
supabase.com postgres db
192.168.1.1:8080 (router admin gateway)`,
  },
  {
    name: 'Productivity & SaaS',
    text: `Team subscriptions:
- notion.so (25 seats)
- figma.com (10 designers)
- slack.com (messaging)
- linear.app (18 licenses)
- zoom.us (conference rooms)
- spotify.com (breakroom)`,
  },
];

export function DomainInput({
  rawText,
  setRawText,
  onAnalyze,
  isLoading,
  provider,
  hasApiKey,
  onOpenConfig,
}: DomainInputProps) {
  const [showPills, setShowPills] = useState(true);

  // Compute live extraction details with memoization
  const extraction: DomainExtractionResult = useMemo(() => {
    return extractDomainsDetailed(rawText);
  }, [rawText]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (extraction.domains.length === 0) return;
    onAnalyze(extraction.domains, extraction.metadataMap, extraction.stats);
  };

  const isMissingOpenAiKey = provider === 'openai' && !hasApiKey;

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl shadow-xs p-5 sm:p-6 mb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-100">
        <div>
          <label
            htmlFor="messy-input-textarea"
            className="text-sm font-semibold text-zinc-900 flex items-center gap-2"
          >
            <span>Paste your domains, logs, or server lists:</span>
          </label>
          <p className="text-xs text-zinc-500 mt-0.5">
            URLs, domain lists, IP hosts with ports, and account/session counts are accurately extracted.
          </p>
        </div>

        {/* Presets */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-[11px] font-medium text-zinc-400 uppercase tracking-wider mr-1 hidden sm:inline">
            Presets:
          </span>
          {SAMPLE_PRESETS.map((preset) => (
            <button
              key={preset.name}
              type="button"
              id={`preset-${preset.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
              onClick={() => setRawText(preset.text)}
              className="text-xs px-2.5 py-1 rounded-md bg-zinc-100 hover:bg-zinc-200 text-zinc-700 transition-colors whitespace-nowrap font-medium"
            >
              {preset.name}
            </button>
          ))}
          {rawText && (
            <button
              type="button"
              id="clear-input-text-btn"
              onClick={() => setRawText('')}
              className="text-xs p-1 text-zinc-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors"
              title="Clear input"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-4 space-y-4">
        <div className="relative">
          <textarea
            id="messy-input-textarea"
            rows={8}
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
            placeholder={`Example:\nchase.com 12 accounts\nwellsfargo.com 4 accounts\naa.com 8 accounts\namazon.com 6 accounts\n192.168.217.50:446`}
            className="w-full p-3.5 sm:p-4 text-sm font-mono text-zinc-800 bg-zinc-50/70 border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/20 focus:border-zinc-900 transition-all resize-y placeholder:text-zinc-400 leading-relaxed"
          />
        </div>

        {/* Live detection preview with accurate accounting */}
        {rawText.trim() && (
          <div className="p-3.5 bg-zinc-50 border border-zinc-200 rounded-xl space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center space-x-1.5 font-medium text-zinc-700">
                {extraction.domains.length > 0 ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      Accurate Site Count:{' '}
                      <strong className="text-zinc-900">{extraction.domains.length} unique sites/hosts</strong>{' '}
                      detected
                    </span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />
                    <span>No valid website domains or host IP addresses detected yet</span>
                  </>
                )}
              </div>

              {extraction.domains.length > 0 && (
                <button
                  type="button"
                  id="toggle-pills-btn"
                  onClick={() => setShowPills(!showPills)}
                  className="text-[11px] text-zinc-500 hover:text-zinc-800 underline font-medium"
                >
                  {showPills ? 'Hide itemized list' : 'Show itemized list'}
                </button>
              )}
            </div>

            {/* Accurate Accounting Badges */}
            {extraction.domains.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-zinc-200/60 text-[11px]">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-zinc-200/80 text-zinc-700 font-medium">
                  <Hash className="w-3 h-3 text-zinc-500" />
                  Pasted: <strong>{extraction.stats.pastedLinesCount} lines</strong>
                </span>

                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200/60 font-medium">
                  <Globe className="w-3 h-3 text-blue-600" />
                  Mentions: <strong>{extraction.stats.totalDetectedItems}</strong>
                </span>

                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200/60 font-medium">
                  <Layers className="w-3 h-3 text-emerald-600" />
                  Unique Targets: <strong>{extraction.stats.uniqueDomainsCount}</strong>
                </span>

                {extraction.stats.duplicateMentionsCount > 0 && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200/60 font-medium">
                    Consolidated Repeats: <strong>{extraction.stats.duplicateMentionsCount}</strong>
                  </span>
                )}

                {Boolean(
                  extraction.stats.totalInstancesOrAccounts &&
                  extraction.stats.totalInstancesOrAccounts > extraction.stats.uniqueDomainsCount
                ) && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-purple-50 text-purple-800 border border-purple-200/60 font-medium">
                    Accounts/Items Logged: <strong>{extraction.stats.totalInstancesOrAccounts}</strong>
                  </span>
                )}
              </div>
            )}

            {/* Itemized List with context labels */}
            {showPills && extraction.items.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2 max-h-36 overflow-y-auto pt-1">
                {extraction.items.map((item) => {
                  const isIp = /^(?:\d{1,3}\.){3}\d{1,3}/.test(item.domain);
                  return (
                    <span
                      key={item.domain}
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-mono font-medium bg-white text-zinc-800 border border-zinc-200 shadow-2xs"
                    >
                      {isIp && <Server className="w-3 h-3 text-amber-600" />}
                      <span>{item.domain}</span>
                      {item.label && (
                        <span className="text-[10px] px-1 py-0.2 rounded bg-zinc-100 text-zinc-600 font-sans font-semibold">
                          {item.label}
                        </span>
                      )}
                      {!item.label && item.occurrences > 1 && (
                        <span className="text-[10px] px-1 py-0.2 rounded bg-amber-100 text-amber-800 font-sans font-semibold">
                          {item.occurrences}x
                        </span>
                      )}
                    </span>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Missing API Key warning for OpenAI */}
        {isMissingOpenAiKey && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-xs text-amber-800">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                Please enter your OpenAI API Key in Settings to run analysis with OpenAI.
              </span>
            </div>
            <button
              type="button"
              id="open-config-from-warning-btn"
              onClick={onOpenConfig}
              className="font-semibold text-amber-900 underline ml-2 shrink-0"
            >
              Open Settings
            </button>
          </div>
        )}

        {/* Action Button */}
        <button
          type="submit"
          id="analyze-websites-button"
          disabled={isLoading || extraction.domains.length === 0 || isMissingOpenAiKey}
          className={`w-full py-3.5 px-6 rounded-xl font-semibold text-sm flex items-center justify-center space-x-2 transition-all shadow-sm ${
            isLoading || extraction.domains.length === 0 || isMissingOpenAiKey
              ? 'bg-zinc-200 text-zinc-400 cursor-not-allowed'
              : 'bg-zinc-900 text-white hover:bg-zinc-800 active:scale-[0.99]'
          }`}
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-zinc-300" />
              <span>Classifying all {extraction.domains.length} sites (zero omissions)...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>
                🚀 Classify Sites Accurately{' '}
                {extraction.domains.length > 0 && `(${extraction.domains.length} Unique Sites)`}
              </span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
