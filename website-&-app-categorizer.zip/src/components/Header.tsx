import { Globe, Settings, Sparkles } from 'lucide-react';

interface HeaderProps {
  onOpenConfig: () => void;
  activeModel: string;
  provider: 'gemini' | 'openai';
  hasCustomKey: boolean;
}

export function Header({ onOpenConfig, activeModel, provider, hasCustomKey }: HeaderProps) {
  return (
    <header className="border-b border-zinc-200 bg-white/90 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 text-white flex items-center justify-center shadow-sm">
            <Globe className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-semibold tracking-tight text-zinc-900">
                Website & App Categorizer
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                <Sparkles className="w-3 h-3 mr-1" />
                AI Powered
              </span>
            </div>
            <p className="text-xs text-zinc-500 hidden sm:block">
              Extract domains from raw notes & describe what each app does
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3">
          <div className="hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-zinc-100 text-xs text-zinc-600 border border-zinc-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="font-medium text-zinc-700 capitalize">{provider}:</span>
            <span className="text-zinc-500 font-mono">{activeModel}</span>
            {hasCustomKey && (
              <span className="ml-1 text-emerald-600 font-medium">(Custom Key)</span>
            )}
          </div>

          <button
            id="open-config-button"
            onClick={onOpenConfig}
            className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium text-zinc-700 bg-white border border-zinc-300 rounded-lg hover:bg-zinc-50 transition-colors shadow-xs"
            title="Configure AI model and API keys"
          >
            <Settings className="w-3.5 h-3.5 text-zinc-500" />
            <span>Settings</span>
          </button>
        </div>
      </div>
    </header>
  );
}
