import express from 'express';
import http from 'http';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { fallbackCategorizeDomains, buildMarkdown } from './src/utils/domainKnowledge';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasGeminiKey: Boolean(process.env.GEMINI_API_KEY) });
});

app.post('/api/analyze', async (req, res) => {
  try {
    const {
      domains,
      domainMetadata,
      stats,
      provider = 'gemini',
      model = 'gemini-3-flash-preview',
      apiKey,
    } = req.body;

    if (!domains || !Array.isArray(domains) || domains.length === 0) {
      return res.status(400).json({ error: 'Please provide at least one domain to analyze.' });
    }

    // Limit to reasonable batch size per request
    const uniqueDomains = Array.from(
      new Set(
        domains.map((d: string) =>
          String(d)
            .trim()
            .toLowerCase()
            .replace(/^https?:\/\//i, '')
            .replace(/\/.*$/, '')
            .replace(/^www\./i, '')
        )
      )
    ).filter(Boolean);

    if (uniqueDomains.length === 0) {
      return res.status(400).json({ error: 'No valid domains or hosts provided.' });
    }

    if (uniqueDomains.length > 250) {
      return res.status(400).json({ error: 'Please provide up to 250 domains at a time.' });
    }

    // Reconcile and enrich categories to guarantee 100% domain accounting, rich descriptions, and attached counts
    const reconcileAndEnrichCategories = (cats: any[]): any[] => {
      const returnedDomains = new Set<string>();
      const localLookup = new Map<string, any>();
      for (const fbCat of fallbackCategorizeDomains(uniqueDomains, domainMetadata)) {
        for (const fbItem of fbCat.items) {
          localLookup.set(fbItem.domain, fbItem);
        }
      }

      for (const cat of cats) {
        for (const item of cat.items || []) {
          const clean = String(item.domain || '')
            .toLowerCase()
            .trim()
            .replace(/^https?:\/\//i, '')
            .replace(/\/.*$/, '')
            .replace(/^www\./i, '');
          item.domain = clean;
          returnedDomains.add(clean);

          const fb = localLookup.get(clean);
          if (fb) {
            if (!item.siteSubType) {
              item.siteSubType = fb.siteSubType;
            }
            if (!item.description || item.description.length < 15) {
              item.description = fb.description;
            }
            if (!item.rewards) {
              item.rewards = fb.rewards;
            } else {
              if (fb.rewards.isBankOrFinancial && item.rewards.isBankOrFinancial === undefined) {
                item.rewards.isBankOrFinancial = true;
              }
              if (!item.rewards.financialSubType && fb.rewards.financialSubType) {
                item.rewards.financialSubType = fb.rewards.financialSubType;
              }
              if (!item.rewards.financialDetails && fb.rewards.financialDetails) {
                item.rewards.financialDetails = fb.rewards.financialDetails;
              }
            }
          }

          if (domainMetadata && domainMetadata[clean]) {
            item.pastedCount = domainMetadata[clean].count;
            item.pastedLabel = domainMetadata[clean].label;
            item.rawOccurrences = domainMetadata[clean].occurrences;
          }
        }
      }

      // Identify any domains omitted by the AI model
      const missingDomains = uniqueDomains.filter((d) => !returnedDomains.has(d));
      if (missingDomains.length > 0) {
        console.log(`[API] Reconciling ${missingDomains.length} omitted domains:`, missingDomains);
        const fallbackCats = fallbackCategorizeDomains(missingDomains, domainMetadata);
        for (const fbCat of fallbackCats) {
          const existingCat = cats.find((c) => c.name.toLowerCase() === fbCat.name.toLowerCase());
          if (existingCat) {
            existingCat.items.push(...fbCat.items);
          } else {
            cats.push({
              id: `cat-${cats.length}-${fbCat.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
              name: fbCat.name,
              description: fbCat.description,
              items: fbCat.items,
            });
          }
        }
      }

      return cats;
    };

    const domainListStr = uniqueDomains.join(', ');

    if (provider === 'openai') {
      const openAiKey = apiKey || process.env.OPENAI_API_KEY;
      if (!openAiKey) {
        return res.status(400).json({
          error: 'OpenAI API key is missing. Please enter your OpenAI API key in the configuration settings or switch to Gemini.',
        });
      }

      const openAiModel = model.startsWith('gpt') ? model : 'gpt-4o-mini';

      const prompt = `You are a technical domain classification assistant.
Analyze the following list of website domains:
${domainListStr}

Group them into logical categories (like Banking & Financial Services, Crypto Wallets & Exchanges, E-Commerce & Retail, Travel & Hospitality, Tech Infrastructure, Developer Tools, Social Media & Entertainment, etc.).

For each website, identify:
1. Domain name, its specific sub-type (e.g., "Retail Bank", "Crypto Wallet / DeFi", "Crypto Exchange", "Investment & Stock Brokerage", "P2P Digital Payment Wallet", "Credit Card Issuer", "Buy Now Pay Later (BNPL)", "Online Retail Marketplace", "Commercial Airline"), and a clear brief explanation of what that website, software, or app does.
2. Financial App Breakdown: If the site is a financial app, bank, crypto platform, investment brokerage, or payment service, set isBankOrFinancial=true, specify financialSubType (e.g. "Retail & Commercial Bank", "Crypto Exchange & Custodial Wallet", "Self-Custody Crypto Wallet", "Stock & Investment Brokerage", "P2P Payment Wallet", "Credit Card & Lending"), and provide financialDetails explaining further what it does (e.g., whether it holds checking/savings with ACH/wires, stores/trades crypto and allows on-chain wallet withdrawals, trades stocks/ETFs/IRAs, or sends P2P money transfers).
3. Rewards & Points: Whether it offers a loyalty/rewards/cashback system, whether rewards/points can be earned, and whether they can be withdrawn or redeemed.
4. Gift Cards: Whether they sell gift cards or allow using rewards/points to buy or redeem gift cards.
5. 2FA Login Verification: Explicitly state how 2FA verification works when trying to log in:
   - Does Email 2FA work? ("Yes", "No", "Optional", or "N/A")
   - Does Phone Number 2FA work? ("Yes", "No", "Optional", or "N/A")
   - Does it support "Both" (Phone & Email), "Phone Only", "Email Only", "App/Security Key", "None", or "N/A"?
   - Provide a step-by-step login verification guide explaining how to log in (which method triggers first, alternative fallback channels, and verification process).

Return a JSON object with this exact structure:
{
  "categories": [
    {
      "name": "Category Name",
      "description": "Brief description of category",
      "items": [
        {
          "domain": "example.com",
          "siteSubType": "Specific platform type (e.g., Retail Bank, Crypto Wallet, Stock Brokerage, Online Marketplace)",
          "description": "Clear, informative explanation of what this website, software, or app does.",
          "tags": ["tag1", "tag2"],
          "rewards": {
            "hasRewardsOrPoints": true,
            "canEarn": true,
            "canWithdrawOrRedeem": true,
            "rewardsDetails": "Description of reward points earning and withdrawal/redemption capabilities",
            "hasGiftCards": true,
            "giftCardDetails": "Details on whether they sell gift cards or let you buy gift cards with points",
            "isBankOrFinancial": true,
            "financialSubType": "Exact financial type if financial app (e.g., Crypto Wallet / Exchange, Retail Bank, Investment Brokerage, P2P Payment Wallet)",
            "financialDetails": "Detailed explanation of how this financial app works (e.g. checking/savings & ACH/wires, buying/storing/withdrawing crypto, trading stocks/ETFs, or P2P transfers)",
            "supportsPhone2FA": "Yes",
            "supportsEmail2FA": "Yes",
            "twoFactorType": "Both",
            "twoFactorDetails": "Details on phone SMS, email OTP, and authenticator options",
            "loginVerificationGuide": "Step-by-step guide on how to log in using email, phone number, or both"
          }
        }
      ]
    }
  ]
}

Ensure all domains in the input list are accounted for. Do not leave any out. Return only valid JSON.`;

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${openAiKey}`,
        },
        body: JSON.stringify({
          model: openAiModel,
          response_format: { type: 'json_object' },
          messages: [
            {
              role: 'system',
              content: 'You are a technical domain classification assistant. Always respond with valid JSON.',
            },
            {
              role: 'user',
              content: prompt,
            },
          ],
          temperature: 0.3,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const message = errorData?.error?.message || `OpenAI API returned status ${response.status}`;
        return res.status(response.status).json({ error: message });
      }

      const openAiData = await response.json();
      const content = openAiData.choices?.[0]?.message?.content;
      if (!content) {
        throw new Error('No content received from OpenAI');
      }

      const parsed = JSON.parse(content);
      let categories = parsed.categories || [];
      categories = reconcileAndEnrichCategories(categories);

      const markdown = buildMarkdown(categories, stats);

      return res.json({
        categories,
        markdown,
        totalDomains: uniqueDomains.length,
        modelUsed: openAiModel,
        timestamp: new Date().toISOString(),
        stats: stats || {
          pastedLinesCount: uniqueDomains.length,
          totalDetectedItems: uniqueDomains.length,
          uniqueDomainsCount: uniqueDomains.length,
          duplicateMentionsCount: 0,
        },
      });
    }

    // Default: Gemini API using @google/genai
    const geminiKey = apiKey || process.env.GEMINI_API_KEY;
    if (!geminiKey) {
      return res.status(400).json({
        error: 'Gemini API Key is not configured. Please add GEMINI_API_KEY in Settings or enter an API key.',
      });
    }

    const ai = new GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const prompt = `Analyze the following list of website domains and classify them:
${domainListStr}

Group them into intuitive categories (e.g., Banking & Financial Services, Crypto Wallets & Exchanges, E-Commerce & Retail, Travel & Airlines, Tech Infrastructure & Cloud, Developer Tools, Social Media & Entertainment, etc.).

For each website:
1. State the domain, specify its exact platform sub-type (e.g., "Retail Bank", "Crypto Wallet / DeFi", "Crypto Exchange", "Stock & Investment Brokerage", "P2P Payment Wallet", "Credit Card Issuer", "Buy Now Pay Later (BNPL)", "Online Retail Marketplace", "Commercial Airline"), and provide a clear, informative explanation of what that website, software, or app does.
2. Financial App Breakdown: If the site is a financial app, bank, crypto platform, investment brokerage, or payment wallet, set isBankOrFinancial=true, specify financialSubType (e.g., "Retail & Commercial Bank", "Crypto Exchange & Custodial Wallet", "Self-Custody Crypto Wallet", "Stock & Investment Brokerage", "P2P Digital Payment Wallet", "Credit Card & Lending"), and provide financialDetails explaining further what it does (e.g., checking/savings & ACH/wire transfers, buying/storing/withdrawing crypto to external wallets, trading stocks/ETFs/IRAs, or P2P money transfers).
3. Rewards & Points: Check if rewards, loyalty points, or cashback can be earned, and whether points can be withdrawn, cashed out, or redeemed.
4. Gift Cards: Check if they sell gift cards or allow using points/rewards to buy or redeem gift cards.
5. 2FA Login Verification: Explicitly state how 2FA verification works when trying to log in:
   - Does Email 2FA work? ("Yes", "No", "Optional", "N/A")
   - Does Phone Number 2FA work? ("Yes", "No", "Optional", "N/A")
   - Does it support "Both" (Phone & Email), "Phone Only", "Email Only", "App/Security Key", "None", or "N/A"?
   - Provide a step-by-step login verification guide explaining how to log in (which method triggers first, alternative fallback channels, and verification process). Include all input domains.`;

    const normalizedModel =
      model && model.includes('gemini') && model !== 'gemini-3.8-flash'
        ? model
        : 'gemini-3-flash-preview';

    // Prioritize high-availability current models per Gemini guidelines
    const candidateModels = [
      normalizedModel,
      'gemini-3-flash-preview',
      'gemini-2.5-flash',
    ].filter((m, idx, arr) => Boolean(m) && arr.indexOf(m) === idx);

    let aiResponse: any = null;
    let actualModelUsed = candidateModels[0] || 'gemini-3-flash-preview';
    let lastError: any = null;

    for (const m of candidateModels) {
      try {
        console.log(`[API] Attempting model ${m}...`);
        const generatePromise = ai.models.generateContent({
          model: m,
          contents: prompt,
          config: {
            systemInstruction:
              'You are a technical domain classification assistant. Analyze domains, group into logical categories, and clearly explain what each site does. When a site is a financial app, specify its exact financial sub-type (e.g. Retail Bank, Crypto Wallet, Crypto Exchange, Investment Brokerage, P2P Payment Wallet, Credit Card/Lending) and explain its financial capabilities in detail. Also accurately detect rewards/points, gift cards, and phone/email 2FA login verification.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                categories: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING, description: 'Category title' },
                      description: { type: Type.STRING, description: 'Brief category summary' },
                      items: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            domain: { type: Type.STRING, description: 'The domain name' },
                            siteSubType: {
                              type: Type.STRING,
                              description: 'Specific platform sub-type (e.g. Retail Bank, Crypto Wallet / DeFi, Crypto Exchange, Stock & Investment Brokerage, P2P Payment Wallet, Online Marketplace)',
                            },
                            description: {
                              type: Type.STRING,
                              description: 'Clear, informative explanation of what this website, software, or app does',
                            },
                            tags: {
                              type: Type.ARRAY,
                              items: { type: Type.STRING },
                              description: '1 to 3 relevant tags',
                            },
                            rewards: {
                              type: Type.OBJECT,
                              properties: {
                                hasRewardsOrPoints: {
                                  type: Type.BOOLEAN,
                                  description: 'Whether it has a loyalty, rewards, miles, or points system',
                                },
                                canEarn: {
                                  type: Type.BOOLEAN,
                                  description: 'Whether users can earn rewards/points or cashback',
                                },
                                canWithdrawOrRedeem: {
                                  type: Type.BOOLEAN,
                                  description: 'Whether users can withdraw, cash out, or redeem rewards/points',
                                },
                                rewardsDetails: {
                                  type: Type.STRING,
                                  description: 'Specific details about earning and redeeming/withdrawing rewards',
                                },
                                hasGiftCards: {
                                  type: Type.BOOLEAN,
                                  description: 'Whether they sell gift cards or let you buy gift cards with rewards/points',
                                },
                                giftCardDetails: {
                                  type: Type.STRING,
                                  description: 'Details on gift card sales or point-to-gift-card redemption',
                                },
                                isBankOrFinancial: {
                                  type: Type.BOOLEAN,
                                  description: 'Whether this website represents a bank, crypto wallet/exchange, investment brokerage, P2P wallet, or financial institution',
                                },
                                financialSubType: {
                                  type: Type.STRING,
                                  description: 'If financial, exact sub-type: Retail Bank, Crypto Wallet / DeFi, Crypto Exchange, Investment & Brokerage, P2P Payment Wallet, Credit Card & Lending, or BNPL',
                                },
                                financialDetails: {
                                  type: Type.STRING,
                                  description: 'Detailed explanation of how this financial app works (checking/savings & ACH/wires, crypto custody/withdrawals, stock/ETF trading, or P2P transfers)',
                                },
                                supportsPhone2FA: {
                                  type: Type.STRING,
                                  description: 'Whether phone number 2FA works: "Yes", "No", "Optional", or "N/A"',
                                },
                                supportsEmail2FA: {
                                  type: Type.STRING,
                                  description: 'Whether email 2FA works: "Yes", "No", "Optional", or "N/A"',
                                },
                                twoFactorType: {
                                  type: Type.STRING,
                                  description: 'Whether "Both", "Phone Only", "Email Only", "App/Security Key", "None", or "N/A" work when trying to log in',
                                },
                                twoFactorDetails: {
                                  type: Type.STRING,
                                  description: 'Details regarding phone number SMS/Voice, email OTP, and authenticator app options',
                                },
                                loginVerificationGuide: {
                                  type: Type.STRING,
                                  description: 'Step-by-step guidance on how login verification works (email vs phone number vs both)',
                                },
                              },
                              required: ['hasRewardsOrPoints', 'canEarn', 'canWithdrawOrRedeem', 'hasGiftCards', 'isBankOrFinancial'],
                            },
                          },
                          required: ['domain', 'siteSubType', 'description'],
                        },
                      },
                    },
                    required: ['name', 'items'],
                  },
                },
              },
              required: ['categories'],
            },
          },
        });

        // 20 second timeout per model call allowing sufficient time for structured schema generation
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Model ${m} timed out after 20s`)), 20000)
        );

        aiResponse = await Promise.race([generatePromise, timeoutPromise]);

        if (aiResponse?.text) {
          actualModelUsed = m;
          console.log(`[API] Successfully analyzed with model: ${m}`);
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[API] Model ${m} failed:`, err?.message || err);
        // If first model timed out, don't cascade another long wait—fall back gracefully
        if (err?.message?.includes('timed out')) {
          break;
        }
      }
    }

    let categories: any[] = [];
    let fallbackUsed = false;
    let note: string | undefined = undefined;

    if (aiResponse && aiResponse.text) {
      try {
        let cleaned = aiResponse.text.trim();
        // Remove markdown codeblock wrapper if present
        if (cleaned.startsWith('```json')) {
          cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        } else if (cleaned.startsWith('```')) {
          cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
        }

        const parsed = JSON.parse(cleaned);
        categories = (parsed.categories || []).map((cat: any, idx: number) => ({
          id: `cat-${idx}-${cat.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
          name: cat.name,
          description: cat.description || '',
          items: cat.items || [],
        }));
      } catch (parseErr) {
        console.warn('[API] JSON parse failed, engaging fallback engine:', parseErr);
        aiResponse = null;
      }
    }

    if (categories.length > 0) {
      categories = reconcileAndEnrichCategories(categories);
    }

    // Seamless fallback to domain intelligence engine if Gemini models are overloaded
    if (!aiResponse || categories.length === 0) {
      console.warn('[API] Gemini models temporarily experiencing demand spikes. Engaging built-in domain intelligence engine.');
      fallbackUsed = true;
      actualModelUsed = 'Domain Intelligence Engine (Auto-Fallback)';
      note = 'Gemini API was temporarily experiencing high demand on Google servers. Domains were classified using the built-in domain intelligence engine.';

      const fallbackCats = fallbackCategorizeDomains(uniqueDomains, domainMetadata);
      categories = fallbackCats.map((cat, idx) => ({
        id: `cat-${idx}-${cat.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
        name: cat.name,
        description: cat.description,
        items: cat.items,
      }));
    }

    const markdown = buildMarkdown(categories, stats);

    return res.json({
      categories,
      markdown,
      totalDomains: uniqueDomains.length,
      modelUsed: actualModelUsed,
      timestamp: new Date().toISOString(),
      fallbackUsed,
      note,
      stats: stats || {
        pastedLinesCount: uniqueDomains.length,
        totalDetectedItems: uniqueDomains.length,
        uniqueDomainsCount: uniqueDomains.length,
        duplicateMentionsCount: 0,
      },
    });
  } catch (err: any) {
    console.error('Analysis error:', err);
    let errorMsg = err?.message || 'An unexpected error occurred while analyzing the domains.';
    try {
      const parsed = JSON.parse(errorMsg);
      if (parsed?.error?.message) {
        errorMsg = parsed.error.message;
      }
    } catch {
      // not json, keep original
    }
    res.status(500).json({
      error: errorMsg,
    });
  }
});

async function startServer() {
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
